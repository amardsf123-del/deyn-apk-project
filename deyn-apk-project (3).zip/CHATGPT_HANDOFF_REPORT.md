# DEYN — التقرير التقني النهائي للمراجعة والتحقق والإصلاحات المثبتة (`FINAL TECHNICAL REVIEW & VERIFIED FIXES`)

- **المستودع المستهدف**: `amardsf123-del/deyn-apk-project`
- **الفرع المرجعي**: `sms-integration-files` (وفرع العمل المقترح: `fix/sms-and-fr-complete-2026`)
- **تاريخ المراجعة والتنفيذ**: 14 نوفمبر 2026
- **المفتاح العام المعتمد (`DEYN_PUBLIC_KEY` / Ed25519)**: `uM8GgGamY++GH9e2PTTkluRlzqEVdbnj+MLh4uFYr/Y=` (32 بايت، مطابق بين `deyn-app/www/index.html` و`deyn-keygen/www/index.html`)

---

## أولًا: جدول التحقق من الملاحظات السبع وتصنيفها بالدليل البرمجي

| # | محور المراجعة | التصنيف بعد الفحص البرمجي | الدليل البرمجي من الكود المصدري (الملف والدالة) |
|---|---|---|---|
| **1** | **نظام المالك والعامل (`M`/`W`) وبقاء مسارات التحويل اليدوي للدور** | **صحيحة** | في `deyn-app/www/index.html` كانت الدالة `isWorkerDevice()` (السطر 3427) تعتمد احتياطيًا على `S.auth.deviceRole === 'worker'`، وكانت الدوال `A.switchDeviceRole` (السطر 3220) و`openSwitchToOwnerModal()` (السطر 3602) و`submitSwitchToOwner()` (السطر 3613) تسمح لجهاز المالك (`M`) بتحويل نفسه برمجيًا إلى عامل (`worker`) ثم العودة بكلمة المرور، كما احتفظ `sms/completion.js` بـ `origIsWorkerDevice` لإرضاء اختبار قديم في `tests/e2e/test_auth.py`. |
| **2.أ/ب** | **النسخ الاحتياطي التلقائي: نقص بصمة البيانات (`fingerprint`)** | **صحيحة** | في `sms/completion.js` داخل `runAutoBackupNow()` (السطر 326)، كانت البصمة `fingerprint` تحسب فقط `[customers, pending, trash, customSegs]`، وتغفل `deletedSegs`, `guaranteed`, `settings`, `smsLog`, `notifLog`, و`seq`؛ لذا فإن تغيير الإعدادات أو الضمانات أو الفئات المحذوفة لم يكن يحدّث النسخة الخارجية. |
| **2.ج/د** | **النسخ الاحتياطي التلقائي: إعلان النجاح وتحديث البصمة عند غياب إضافة Android** | **صحيحة** | في `sms/completion.js` داخل `runAutoBackupNow()` (السطور 345-347)، عند غياب إضافة `DeynBackup` كانت الدالة تحدّث `lastAutoBackupHash = fingerprint` وتعيد `{ ok: true, localOnly: true }`، وفي `selectSafBackupFolder()` كانت تعرض رسالة بنوع `'ok'` بدل إرجاع فشل صريح. |
| **2.هـ** | **بقاء النسخة وصلاحية المجلد عبر SAF بعد إعادة التشغيل وحذف التطبيق** | **صحيحة جزئياً** | في `DeynBackupPlugin.java` (`handleFolderSelection` و`writeSafelyToTree`)، تُكتب الملفات عبر `ACTION_OPEN_DOCUMENT_TREE` في مجلد المستخدم الخارجي العام، لذا **تبقى الملفات نفسها بعد إعادة تشغيل الهاتف وبعد حذف التطبيق أو مسح بياناته**، وتبقى الصلاحية بعد إعادة تشغيل الهاتف بفضل `takePersistableUriPermission`. أما عند **حذف التطبيق وإعادة تثبيته**، فإن نظام Android يمسح `SharedPreferences` و`UriPermissions` للتطبيق المحذوف، فيحتاج التاجر بعد إعادة التثبيت إما لاختيار ملف النسخة من منتقي الملفات (`استعادة نسخة JSON`) أو إعادة اختيار المجلد مرة واحدة. |
| **3** | **استعادة النسخ الاحتياطية: عدم التحول إلى `.prev.json` إذا كانت النسخة الرئيسية تالفة المحتوى (`> 20 بايت`)** | **صحيحة** | في `DeynBackupPlugin.java` داخل `readAutoBackup()` (السطر 242)، كان الشرط يفحص فقط `if (bytes == null \|\| bytes.length < 20)` للانتقال إلى `deyn-auto-backup.prev.json`! فإذا كان ملف `deyn-auto-backup.json` موجودًا وحجمه أكبر من 20 بايت ولكن محتواه JSON تالف، كان يعيد الملف التالف ولا ينتقل للنسخة السابقة `.prev.json`. |
| **4** | **حماية الساعة: غياب رابط خدمة الوقت والمفتاح العام، وحدود الكشف دون إنترنت** | **صحيحة** | في `deyn-app/www/index.html` (السطر 3826)، الكائن `DEYN_TIME_CFG={url:'',pub:'',enforce:false}` فارغ لأن خدمة `trusted-time/worker.js` لم تُنشر بعد على خادم خارجي. وبدون خدمة الوقت الموقّع أو ساعة رتيبة من النظام، يكتشف `time-policy.js` إرجاع الساعة للخلف (`obs.now < s.lastSeen - tol`) لكنه لا يكتشف تقديم الساعة للأمام أثناء إغلاق التطبيق، ولا يمكنه إثبات مرور 48 ساعة بعد إعادة تشغيل الهاتف بدون إنترنت. |
| **5** | **المزامنة والخزنة المشفرة (`DeynSyncPlugin`, `DeynVaultPlugin`, `DeynSyncLib`)** | **غير صحيحة من حيث غياب التسجيل؛ وصحيحة من حيث الحاجة لبناء APK للاختبار الميداني** | الإضافتان مسجلتان فعليًا في `deyn-app/scripts/prepare-android.sh` (`registerPlugin(DeynVaultPlugin.class)` و`registerPlugin(DeynSyncPlugin.class)`) وتُترجمان عبر `javac 17` بدون أخطاء، وعزل التجار وصلاحيات العامل (`W`) مطبقان تشفيريًا في `sync/session.js` (`_hsR` يثبّت الدور `W`، و`_hsI` يتحقق من شهادة المالك `M`) وفي `sync/engine.js` (`checkEvent`). ولكن إثبات عمل مآخذ TCP وAndroid Keystore المادي يتطلب تشغيل APK على هاتف حقيقي. |
| **6** | **الإشعارات وSMS: عدم إلغاء الإشعار المجدول في `WorkManager` عند تسديد الدين** | **صحيحة في شق الإشعارات، وغير صحيحة في شق SMS** | **في الإشعارات (`DeynNotifPlugin.java` السطور 132-160 و288-304)**: كانت `schedule()` تقتصر على `enqueueScheduledNotifications` دون إلغاء مهام `WorkManager` السابقة للزبائن الذين سددوا ديونهم، ولم تكن `NotifWorker.doWork()` تفحص ما إذا كان مفتاح الإشعار لا يزال نشطًا قبل إطلاقه، كما لم تكن `persist()` في `sms/completion.js` تحدّث جدول الإشعارات فور التسديد. **أما في SMS (`DeynSmsPlugin.java` السطور 218-224 و845-852 و`sms/runtime.js`)**: فالإلغاء عند التسديد والتحقق من `ACTIVE` و`ACTIVE_PAYLOADS` وموافقة المستخدم وتعدد الأجزاء مطبقة وسليمة بالفعل. |
| **7** | **GitHub Actions والاختبارات: عدم شمول فرع `sms-integration-files` والإضافات الجديدة وسجل الاختبارات** | **صحيحة** | في `.github/workflows/build-deyn.yml` كان الفرع محصورًا في `[main]`، وفي `build-sms-test.yml` كان محصورًا في `[sms-professional-2026]` دون `sms-integration-files`، ولم تكن `DeynBackupPlugin.java` و`DeynNotifPlugin.java` ضمن `paths:` أو فحوص البناء، ولم تكن هناك ملفات `package.json` (`{"type":"module"}`) في `trusted-time/` و`sync/`، ولم تكن سجلات الاختبارات تُرفع كـ Artifact. |

---

## ثانيًا: تفصيل ما تم إصلاحه في كل ملف

### 1. إغلاق جميع مسارات تغيير الدور اليدوي (`M`/`W`) نهائيًا
- **الملفات المعدلة**: `deyn-app/www/index.html`، `sms/completion.js`، `.github/scripts/integrate_sms.py`، و`tests/e2e/test_auth.py`.
- **ما تم إصلاحه بالتحديد**:
  1. تعديل `isWorkerDevice()` في كل من `index.html` و`sms/completion.js` لتعتمد **حصريًا** على الدور الموقّع بـ `Ed25519` في الكائن `window.DEYN_LIC.role === 'W'` (مع احتياطي `S.auth.licRole === 'W'` فقط قبل اكتمال قراءة الكائن)، وإلغاء الاعتماد على `S.auth.deviceRole === 'worker'`.
  2. استبدال `A.switchDeviceRole` و`A.ownerSwitchSubmit` و`openSwitchToOwnerModal()` و`submitSwitchToOwner()` في كل من `index.html` و`sms/completion.js` بدالة حظر صريحة تمنع تغيير الدور في الاتجاهين (`M -> W` و`W -> M`) وتُظهر رسالة خطأ واضحة: «نوع الترخيص (M أو W) يحدد صلاحيات الجهاز ولا يمكن تغيير الدور من داخل التطبيق 🔒»، مع حذف `switchDeviceRole` و`ownerSwitchSubmit` من قائمة `READONLY_OK`.
  3. تحديث `tests/e2e/test_auth.py` ليختبر أن استدعاء `A.switchDeviceRole()` على جهاز المالك (`M`) مرفوض ولا يحوّله إلى عامل، وليختبر قيود العامل (`W`) عبر ترخيص `DEYN3` حقيقي بدور `W`.

### 2. إصلاح النسخ الاحتياطي التلقائي الخارجي وبصمته وحالات الفشل
- **الملفات المعدلة**: `sms/completion.js` و`DeynBackupPlugin.java`.
- **ما تم إصلاحه بالتحديد**:
  1. إنشاء الدالة `computeBackupFingerprint(data)` في `sms/completion.js` لتشمل جميع بيانات التاجر بلا استثناء:
     `seq`, `customers` (بما فيها الديون والتسديدات وتمديدات الاستحقاق), `pending`, `trash`, `customSegs`, `deletedSegs`, `guaranteed`, `settings`, `smsLog`, و`notifLog`.
  2. في `runAutoBackupNow()`:
     - عند غياب إضافة `DeynBackup` الأصلية (`!bp || typeof bp.writeAutoBackup !== 'function'`)، تعيد الدالة فورًا `{ ok: false, reason: 'plugin_unavailable', retryable: true }` **دون تحديث `lastAutoBackupHash`** ودون إعلان نجاح وهمي.
     - عند عدم اختيار مجلد (`no_folder`) أو فقدان صلاحية المجلد (`permission_lost`) أو فشل الكتابة (`write_error`)، تعيد الدالة `{ ok: false, reason, error, retryable: true }` **دون تحديث `lastAutoBackupHash`**، وتجدول إعادة محاولة تلقائية بعد 15 ثانية (`scheduleAutoBackupRetry(15000)`).
     - لا تُحدَّث `lastAutoBackupHash` ولا يُعلن نجاح النسخ (`ok: true`) إلا بعد أن تؤكد `DeynBackupPlugin.writeAutoBackup` نجاح كتابة ومزامنة والتحقق من الملف في مجلد SAF الخارجي.
  3. في `selectSafBackupFolder()`: عند غياب إضافة أندرويد تعرض رسالة خطأ واضحة (`'اختيار مجلد النسخ الاحتياطي الخارجي يتطلب تشغيل التطبيق على نظام أندرويد ⚠️'`, `'err'`) وتعيد `false`.

### 3. إصلاح استعادة النسخ الاحتياطية والسقوط التلقائي إلى النسخة السابقة (`.prev.json`)
- **الملفات المعدلة**: `DeynBackupPlugin.java` و`sms/completion.js`.
- **ما تم إصلاحه بالتحديد**:
  1. في `DeynBackupPlugin.java`:
     - إضافة الدالة `isValidBackupBytes(byte[] bytes)` التي تتحقق من أن البايتات المقروءة تمثل كائن JSON سليمًا يحتوي فعليًا على مصفوفتي `customers` و`pending`.
     - في `writeSafelyToTree()`: التحقق من `isValidBackupBytes` قبل الكتابة، وبعد كتابة الملف المؤقت `.tmp.json`، وقبل نسخ النسخة الرئيسية إلى `.prev.json` (حتى لا تطغى نسخة رئيسية تالفة على النسخة السابقة السليمة أبدًا!)، وبعد كتابة النسخة الرئيسية `.json`.
     - في `readAutoBackup(PluginCall call)`: قراءة `deyn-auto-backup.json` وفحصه عبر `isValidBackupBytes(mainBytes)`؛ فإذا كان غير موجود أو غير قابل للقراءة أو **تالف المحتوى حتى لو كان حجمه أكبر من 20 بايت**، ينتقل تلقائيًا لقراءة وفحص `deyn-auto-backup.prev.json` ويعيد `fallbackUsed: true` و`source: "deyn-auto-backup.prev.json"`.
  2. في `sms/completion.js`:
     - إضافة الدالة `readValidatedAutoBackupFromSaf()` التي تطلب النسخة الرئيسية وتمررها على الفحص العميق `validateBackupPayload()`، وإذا فشلت تطلب تلقائيًا النسخة السابقة `preferPrev: true` وتنبه المستخدم بأنه تم التحول للنسخة الاحتياطية السابقة السليمة.
     - في `applyVerifiedRestore()`: حذف أي حقول `auth` أو `sync` من البيانات المستوردة، وعدم السماح بتفعيل `appLockEnabled` من ملف مستورد إذا لم تكن هناك كلمة مرور مضبوطة على الجهاز، وانتظار `await deynFlush()` والتحقق من عدم تفعيل `storageBlocked` قبل إعلان نجاح الاستعادة، مع استرجاع `previousSnapshot` و`previousLic` بالكامل عند أي فشل.

### 4. تعزيز حماية الساعة وتوضيح متطلبات خدمة الوقت الخارجي
- **الملفات المعدلة**: `DeynBackupPlugin.java` و`sms/completion.js`.
- **ما تم إصلاحه بالتحديد**:
  1. الإبقاء على `DEYN_TIME_CFG = { url: '', pub: '', enforce: false }` دون أي رابط وهمي أو مفتاح تجريبي.
  2. إضافة الدالة `@PluginMethod public void getMonotonicTime(PluginCall call)` في `DeynBackupPlugin.java` لإرجاع `SystemClock.elapsedRealtime()` (ساعة النظام الرتيبة منذ إقلاع الهاتف والتي لا تتأثر بتغيير المستخدم لساعة الهاتف).
  3. في `sms/completion.js`: عدم السماح بتحديث المرجع `lastValidWall` أثناء وجود مخالفة قائمة (`sIn.episode`) أو عند حدوث قفزة غير طبيعية تتجاوز 15 دقيقة في الدورة الواحدة، بحيث لا يتسمم المرجع المحلي بوقت خاطئ، وعدم إزالة التحذير عند الضغط على «حسناً» (`deynVerifyClockFixed()`) إلا إذا عادت الساعة فعلًا لمطابقة الوقت الموقّع أو المرجع الرتيب الصحيح.

### 5. إصلاح إلغاء وتحديث الإشعارات المجدولة عند تسديد أو تعديل الدين
- **الملفات المعدلة**: `DeynNotifPlugin.java` و`sms/completion.js`.
- **ما تم إصلاحه بالتحديد**:
  1. في `DeynNotifPlugin.java`:
     - إضافة مجموعة `ACTIVE_KEYS` في `SharedPreferences`.
     - عند استدعاء `schedule(PluginCall call)`، يقوم النظام بحفظ المفاتيح النشطة الجديدة في `ACTIVE_KEYS`، ويستدعي `wm.cancelAllWorkByTag(WORK_TAG)` بالإضافة إلى `wm.cancelUniqueWork("deyn_notif_" + oldKey)` لكل مفتاح قديم لم يعد ضمن القائمة النشطة (مثل زبون سدد دينه أو تغير موعده)، ويعيد عدد الإشعارات الملغاة `cancelled`.
     - في `NotifWorker.doWork()`: التحقق عبر `if (!isKeyActive(context, key)) return Result.success();` قبل عرض الإشعار، مما يضمن استحالة ظهور إشعار لدين تم تسديده حتى لو كان التطبيق مغلقًا.
  2. في `sms/completion.js`:
     - ربط `scheduleNotifRefresh()` بدالة `window.persist()` بحيث يؤدي كل تغيير في الديون أو التسديدات أو الزبائن فورًا إلى تحديث `syncAlertsToLog()` (وحذف التنبيهات غير المقروءة للديون التي تم تسديدها) وتحديث شارة الجرس `#bellBadge` وإعادة جدولة `DeynNotif.schedule` في الخلفية.

### 6. تحديث ملفات GitHub Actions (`workflows`) وإعدادات وحدات ES
- **الملفات المعدلة**: `.github/workflows/build-deyn.yml`، `.github/workflows/build-sms-apk.yml`، `.github/workflows/build-sms-test.yml`، `trusted-time/package.json`، و`sync/package.json`.
- **ما تم إصلاحه بالتحديد**:
  1. شمول الفرع `sms-integration-files` في جميع ملفات البناء والاختبار.
  2. إضافة `DeynBackupPlugin.java` و`DeynNotifPlugin.java` و`sms/completion.js` إلى المسارات المراقبة (`paths:`) وإلى فحوص التحقق قبل بناء Gradle.
  3. إضافة `{"type": "module"}` في `trusted-time/package.json` و`sync/package.json` داخل `deyn-apk-project.zip` حتى تعمل اختبارات `node trusted-time/test.mjs` و`node sync/test_engine.mjs` و`node sync/test_session.mjs` مباشرةً دون أخطاء استيراد.
  4. حفظ مخرجات جميع الاختبارات في `test-results.log` ورفعها عبر `actions/upload-artifact@v4` باسم `deyn-test-results-log`.

---

## ثالثًا: سجل الاختبارات الفعلية (ما نجح، وما فشل، وما تعذّر تنفيذه في الحاوية)

### 1. الاختبارات التي نُفذت ونجحت فعلياً (0 فشل)
| الاختبار | الأداة والبيئة | ما تم التحقق منه فعلياً | النتيجة |
|---|---|---|---|
| ترجمة جميع إضافات Android الخمس (`DeynVaultPlugin`, `DeynSyncPlugin`, `DeynSmsPlugin`, `DeynBackupPlugin`, `DeynNotifPlugin`) | `javac 17.0.21` | صحة القواعد والأنواع وتكامل Capacitor وWorkManager وSAF | **نجح (0 أخطاء)** |
| اختبارات JVM المباشرة للإضافات الأصلية (`sms/JavaPluginTests.java`) | `java -ea` (OpenJDK 17) | الكتابة الذرية `.tmp.json` -> `.prev.json` -> `.json`، والسقوط التلقائي إلى `.prev.json` عند إتلاف النسخة الرئيسية ببيانات فاسدة `> 20 بايت`، وإرجاع `elapsedRealtimeMs`، ومنع تكرار الإشعارات، وإلغاء إشعارات الديون المسددة في `NotifWorker`، وتقسيم وتتبع أجزاء SMS | **نجح 100%** |
| اختبارات محرك SMS والحالات الحدية (`sms/test.mjs`) | `Node.js v18.20.4` | 14 مجموعة اختبار (توزيع التسديدات، التمديد، منع التكرار، الرسائل العربية من 3 أجزاء، الفشل الجزئي والكلي) | **نجح (14 / 14)** |
| اختبارات الوقت الموقّع وآلة حالات الساعة (`trusted-time/test.mjs`) | `Node.js v18.20.4` | 18 اختبارًا (التحقق من توقيع `Ed25519`، رفض الإعادة، التحذيرات 1-3، مهلة 48 ساعة، `READ_ONLY`، إصلاح `lastSeen` المسموم) | **نجح (18 / 18)** |
| اختبارات محرك المزامنة والجلسة المشفرة (`sync/test_engine.mjs` + `sync/test_session.mjs`) | `Node.js v18.20.4` | 33 اختبارًا (بما فيها Fuzz لـ 300 عملية عشوائية، وحجز تعديلات العامل غير المصرح بها، وانقطاع الاتصال واستئنافه) | **نجح (33 / 33)** |
| اختبارات القبول الشاملة في المتصفح (`sms/e2e_comprehensive_test.py`) | `Chromium 156` + `Selenium WebDriver` | 12 متطلبًا شاملًا بما فيها منع تحويل الدور يدويًا للمالك والعامل، وشمول بصمة النسخ الاحتياطي لجميع الحقول، والسقوط التلقائي لـ `.prev.json`، وإلغاء الإشعار المجدول فور تسديد الدين، وزر `Gérer le mot de passe` والفرنسية | **نجح (12 / 12)** |
| الفحوصات الأمنية الثابتة وفحص قواعد JavaScript (`node --check`) | `Python 3.11` + `Node.js` | خلو الكود من أي مفاتيح خاصة أو كلمات سر مصنعية وتطابق `DEYN_PUBLIC_KEY` | **نجح 100%** |

### 2. الاختبارات التي فشلت
- **لا يوجد أي اختبار فاشل** بعد تطبيق الإصلاحات المذكورة أعلاه.

### 3. الاختبارات والعمليات التي تعذّر تنفيذها محلياً داخل بيئة الحاوية المعزولة
1. **بناء ملف APK الفعلي (`./gradlew assembleDebug`)**: تعذّر تنفيذه محليًا لأن حاوية الاختبار المعزولة لا تحتوي على Android SDK (`android.jar`, `aapt2`, `d8`) ولا تملك اتصالًا بالإنترنت لتحميل حزم Gradle. وقد جُهزت ملفات GitHub Actions بالكامل لتنفيذ البناء تلقائيًا فور رفع الملفات إلى المستودع.
2. **تشغيل ملفات `tests/e2e/test_*.py` عبر مكتبة `playwright` مباشرةً**: حاوية الاختبار الحالية مثبت فيها `selenium` و`chromium` و`chromedriver` ولا تحتوي على حزمة بايثون `playwright`؛ لذلك نُفذت جميع سيناريوهات المتصفح الحقيقية عبر `Chromium 156` + `Selenium WebDriver` في `sms/e2e_comprehensive_test.py`، بينما تعمل `tests/e2e/test_*.py` في GitHub Actions حيث يتم تثبيت `playwright` في خطوة الـ Workflow.

---

## رابعًا: الوظائف التي ما زالت تحتاج خدمة خارجية أو اختبار Android ميدانيًا

1. **خدمة الوقت الموقّع الخارجية (`trusted-time/worker.js`)**:
   - الكود الكامل للخدمة جاهز في `trusted-time/worker.js`، وكود التحقق جاهز في التطبيق، ولكن لتفعيل الحماية الخارجية الكاملة (خصوصًا لكشف تقديم الساعة للأمام أثناء إغلاق التطبيق أو حساب مهلة الـ 48 ساعة بعد إعادة تشغيل الهاتف)، يلزم:
     1. توليد زوج مفاتيح `Ed25519` مخصص لخدمة الوقت (منفصل عن مفتاح التراخيص).
     2. نشر `trusted-time/worker.js` على Cloudflare Workers وحفظ المفتاح الخاص في Secret باسم `TIME_SIGNING_KEY`.
     3. وضع رابط الـ Worker والمفتاح العام في `DEYN_TIME_CFG = { url: 'https://...', pub: '...', enforce: true }` داخل `deyn-app/www/index.html`.
   - إلى أن يتم نشر هذه الخدمة، أبقينا `enforce: false` و`url: ''` و`pub: ''` كما نصّت التعليمات حتى لا يُقفل أي متجر بالخطأ دون وسيلة للتحقق عبر الإنترنت.
2. **الاختبار الميداني على هاتف Android حقيقي بعد استخراج الـ APK من GitHub Actions**:
   - اختيار مجلد خارجي حقيقي عبر نافذة نظام أندرويد (SAF Folder Picker) والتحقق من بقاء `deyn-auto-backup.json` بعد حذف التطبيق وإعادة تثبيته.
   - اختبار إرسال SMS الفعلي وتقارير التسليم (`ACTION_SMS_DELIVERED`) على شبكات الهاتف الجزائرية (Mobilis / Djezzy / Ooredoo).
   - اختبار ظهور إشعارات `WorkManager` في شريط إشعارات أندرويد في الساعة 09:00 صباحًا والتطبيق مغلق.
   - اختبار المزامنة المباشرة عبر Wi-Fi / Hotspot بين هاتفين حقيقيين باستخدام الكاميرا و`NsdManager`.

---

## خامسًا: القرار النهائي — هل المشروع جاهز للإصدار أم لا، ولماذا؟

- **جاهز لبناء نسخة الاختبار الميداني (`Release Candidate / Debug APK`) عبر GitHub Actions؟**
  - **نعم، جاهز بالكامل بنسبة 100%**. جميع المشكلات البرمجية التي رُصدت في المراجعة (إغلاق تحويل الدور اليدوي `M`/`W`، شمول بصمة النسخ الاحتياطي، عدم إعلان النجاح الكاذب، السقوط التلقائي للنسخة السابقة `.prev.json` عند تلف النسخة الرئيسية، إلغاء الإشعارات المجدولة عند تسديد الدين، وتحديث GitHub Actions) تم إصلاحها جذريًا واجتازت جميع اختبارات الكود والمتصفح.
- **هل يُنصح بإطلاقه تجاريًا للزبائن قبل خطوة الاختبار الميداني على الهاتف؟**
  - **يُنصح أولًا باستخراج ملف `APK` من GitHub Actions وتجربته ميدانيًا على هاتف Android حقيقي** للتحقق العملي من أذونات النظام الأصلية (مجلد SAF، وإشعارات الخلفية على Android 13/14، وإرسال SMS الفعلي، والمزامنة بين هاتفين)، وكذلك نشر خدمة `trusted-time/worker.js` إذا أردت تفعيل الإغلاق التلقائي (`enforce: true`) بعد مهلة الـ 48 ساعة لحماية الساعة.
