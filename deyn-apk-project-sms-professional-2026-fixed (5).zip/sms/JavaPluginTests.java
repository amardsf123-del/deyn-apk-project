package com.deyn.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.work.Data;
import androidx.work.WorkerParameters;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import org.json.JSONObject;

public class JavaPluginTests {
    public static void main(String[] args) throws Exception {
        Context ctx = new Context();
        File safDir = new File("/tmp/java_verify/saf_tree");
        if (safDir.exists()) {
            for (File f : safDir.listFiles()) f.delete();
        }
        safDir.mkdirs();

        // 1. Test DeynBackupPlugin: no_folder check, atomic write, .prev.json rotation, and automatic fallback when main file is corrupted (>20 bytes)
        DeynBackupPlugin backup = new DeynBackupPlugin();
        String json1 = "{\"format\":\"DEYN-BACKUP-V2\",\"version\":2,\"data\":{\"customers\":[{\"id\":\"c1\",\"name\":\"أحمد\"}],\"pending\":[]}}";
        PluginCall writeNoFolder = new PluginCall().put("data", json1);
        backup.writeAutoBackup(writeNoFolder);
        assert writeNoFolder.resolved != null && !writeNoFolder.resolved.optBoolean("ok")
            && "no_folder".equals(writeNoFolder.resolved.optString("reason")) : "Expected no_folder before SAF selection";

        SharedPreferences.MEM.put("tree_uri", "content://tree/deyn");
        PluginCall write1 = new PluginCall().put("data", json1);
        backup.writeAutoBackup(write1);
        Thread.sleep(200);
        assert write1.resolved != null && write1.resolved.optBoolean("ok") : "First atomic backup write failed";

        String json2 = "{\"format\":\"DEYN-BACKUP-V2\",\"version\":2,\"data\":{\"customers\":[{\"id\":\"c1\",\"name\":\"أحمد\"},{\"id\":\"c2\",\"name\":\"سعيد\"}],\"pending\":[]}}";
        PluginCall write2 = new PluginCall().put("data", json2);
        backup.writeAutoBackup(write2);
        Thread.sleep(200);
        assert write2.resolved != null && write2.resolved.optBoolean("ok") : "Second atomic backup write failed";

        File mainFile = new File(safDir, "deyn-auto-backup.json");
        File prevFile = new File(safDir, "deyn-auto-backup.prev.json");
        assert mainFile.isFile() && prevFile.isFile() : "Both main and prev backup files must exist";

        // Simulate external corruption of deyn-auto-backup.json with >20 bytes of corrupt text
        Files.write(mainFile.toPath(), "{CORRUPT_MAIN_FILE_LONGER_THAN_20_BYTES_1234567890}".getBytes(StandardCharsets.UTF_8));
        PluginCall readFallback = new PluginCall();
        backup.readAutoBackup(readFallback);
        assert readFallback.resolved != null && readFallback.resolved.optBoolean("ok") : "readAutoBackup should succeed via fallback";
        assert readFallback.resolved.optBoolean("fallbackUsed") : "Expected fallbackUsed = true when main is corrupt";
        assert "deyn-auto-backup.prev.json".equals(readFallback.resolved.optString("source")) : "Expected source = deyn-auto-backup.prev.json";
        assert json1.equals(readFallback.resolved.optString("data")) : "Expected previous valid backup content";

        // Verify monotonic clock method
        PluginCall monoCall = new PluginCall();
        backup.getMonotonicTime(monoCall);
        assert monoCall.resolved != null && monoCall.resolved.optLong("elapsedRealtimeMs") > 0L : "Expected elapsedRealtimeMs > 0";
        System.out.println("PASS: DeynBackupPlugin atomic write, corrupt main -> .prev.json fallback, and monotonic clock verified.");

        // 2. Test DeynNotifPlugin: deduplication, scheduling, and cancellation of paid/modified debts in NotifWorker
        DeynNotifPlugin notif = new DeynNotifPlugin();
        String nKey = "overdue|c1|2026-11|10";
        assert DeynNotifPlugin.postOnce(ctx, nKey, "DEYN — أحمد", "متأخر بـ 1 يوم", false) : "First post should succeed";
        assert !DeynNotifPlugin.postOnce(ctx, nKey, "DEYN — أحمد", "متأخر بـ 1 يوم", false) : "Duplicate post must be suppressed";

        // Schedule notification for c2, then re-schedule empty list (simulating c2 paid off debt) -> NotifWorker must NOT fire c2!
        JSArray schedArr = new JSArray();
        JSONObject item = new JSONObject();
        item.put("key", "overdue|c2|2026-11|15");
        item.put("title", "DEYN — سعيد");
        item.put("body", "متأخر بـ 1 يوم");
        item.put("at", System.currentTimeMillis() + 3600_000L);
        schedArr.put(item);
        PluginCall sched1 = new PluginCall().put("items", schedArr);
        notif.schedule(sched1);
        assert DeynNotifPlugin.isKeyActive(ctx, "overdue|c2|2026-11|15") : "c2 key should be active after schedule";

        // Now c2 pays off debt -> schedule called with empty items
        PluginCall sched2 = new PluginCall().put("items", new JSArray());
        notif.schedule(sched2);
        assert !DeynNotifPlugin.isKeyActive(ctx, "overdue|c2|2026-11|15") : "c2 key must be inactive after debt paid";
        assert sched2.resolved.optInt("cancelled") == 1 : "Expected 1 cancelled notification";

        // If NotifWorker runs for c2 after c2 paid off debt, it must NOT post the notification
        Data workerData = new Data.Builder()
            .putString("key", "overdue|c2|2026-11|15")
            .putString("title", "DEYN — سعيد")
            .putString("body", "متأخر بـ 1 يوم")
            .build();
        DeynNotifPlugin.NotifWorker worker = new DeynNotifPlugin.NotifWorker(ctx, new WorkerParameters(workerData));
        worker.doWork();
        assert !DeynNotifPlugin.wasFired(ctx, "overdue|c2|2026-11|15") : "Cancelled notification must NOT fire in NotifWorker";
        System.out.println("PASS: DeynNotifPlugin deduplication, schedule update, and paid-debt cancellation in NotifWorker verified.");

        // 3. Test DeynSmsPlugin multipart division and per-part BroadcastReceiver state machine
        String longAr = "السلام عليكم أحمد، تذكير ودي من محل الأمانة بخصوص الرصيد المتبقي 14500 دج المستحق يوم 10/11/2026، بارك الله فيكم وشكرًا لتعاملكم الطيب معنا.";
        DeynSmsPlugin.DispatchResult dr = DeynSmsPlugin.dispatchOnce(ctx, "msg-test-1", "+213550123456", longAr, false, 0L, 1);
        assert dr.dispatched && dr.totalParts >= 2 : "Expected multipart dispatch";
        DeynSmsPlugin.SmsStatusReceiver smsReceiver = new DeynSmsPlugin.SmsStatusReceiver();
        long att = SharedPreferences.MEM.get("attempt_at_msg-test-1") instanceof Long ? (Long) SharedPreferences.MEM.get("attempt_at_msg-test-1") : 0L;
        for (int p = 0; p < dr.totalParts; p++) {
            Intent sentIntent = new Intent(DeynSmsPlugin.ACTION_SMS_SENT).putExtra("id", "msg-test-1").putExtra("partIndex", p).putExtra("partsTotal", dr.totalParts).putExtra("attemptAt", att);
            smsReceiver.setResultCode(android.app.Activity.RESULT_OK);
            smsReceiver.onReceive(ctx, sentIntent);
        }
        JSObject snapSent = DeynSmsPlugin.buildItemSnapshot(ctx.getSharedPreferences("deyn_sms_native", 0), "msg-test-1");
        assert "sent_to_network".equals(snapSent.optString("status")) : "Expected sent_to_network";
        System.out.println("PASS: DeynSmsPlugin multipart division and per-part BroadcastReceiver state machine verified.");
    }
}