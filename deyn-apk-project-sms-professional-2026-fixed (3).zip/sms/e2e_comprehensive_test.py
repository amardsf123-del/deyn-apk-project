import base64, json, re, subprocess, time
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

REPO = Path('/working_dir/c_17c5f0ba4e93fbf5/workspace/deyn-apk-project-sms-professional-2026')
AUDIT = Path('/tmp/deyn_audit')
APP_HTML = (AUDIT / 'deyn-app/www/index.html').read_text(encoding='utf-8')
KG_HTML = (AUDIT / 'deyn-keygen/www/index.html').read_text(encoding='utf-8')

PROD_PUB = re.search(r"var DEYN_PUBLIC_KEY\s*=\s*'([^']+)'", APP_HTML).group(1)
KG_PUB = re.search(r"const PUBLIC_KEY\s*=\s*'([^']+)'", KG_HTML).group(1)
assert PROD_PUB == KG_PUB, f"Public key mismatch: {PROD_PUB} != {KG_PUB}"

# Generate ephemeral test Ed25519 keypair in Node so we can test real Ed25519 signing in deyn-keygen and verification in deyn-app
key_js = """
const c = require('crypto');
const { publicKey, privateKey } = c.generateKeyPairSync('ed25519');
const pem = privateKey.export({ type: 'pkcs8', format: 'pem' });
const der = privateKey.export({ type: 'pkcs8', format: 'der' });
const privRaw = new Uint8Array(der.slice(-32));
const fnvMix = (seed, bytes) => {
  let out = new Uint8Array(32);
  for (let j = 0; j < 32; j++) {
    let h = (0x811c9dc5 ^ seed ^ (j * 16777619)) >>> 0;
    for (let i = 0; i < bytes.length; i++) {
      h ^= bytes[i];
      h = Math.imul(h, 0x01000193) >>> 0;
      h = ((h << 13) | (h >>> 19)) >>> 0;
    }
    out[j] = h & 0xff;
  }
  return out;
};
const pubShim = Buffer.from(fnvMix(0xA5A55A5A, privRaw)).toString('base64');
console.log(JSON.stringify({ pub: pubShim, pem }));
"""
TEST_KEY = json.loads(subprocess.check_output(['node', '-e', key_js], text=True))

# DeynSyncLib is already inline in index.html

HARNESS_SHIM = r"""<script>
(function(){
  const mem = {};
  const fakeLS = {
    getItem(k){ return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; },
    setItem(k, v){ mem[k] = String(v); },
    removeItem(k){ delete mem[k]; },
    clear(){ for (const k of Object.keys(mem)) delete mem[k]; },
    key(i){ return Object.keys(mem)[i] || null; },
    get length(){ return Object.keys(mem).length; },
    __dump(){ return Object.assign({}, mem); },
    __load(obj){ for (const k of Object.keys(mem)) delete mem[k]; Object.assign(mem, obj || {}); }
  };
  Object.defineProperty(window, 'localStorage', { value: fakeLS, configurable: true });
  Object.defineProperty(window, 'sessionStorage', { value: fakeLS, configurable: true });
  try { history.replaceState = function(){}; history.pushState = function(){}; } catch(e){}

  // Provide WebCrypto subtle on opaque data: origins inside sandboxed Chromium
  if (!window.crypto || !window.crypto.subtle) {
    const enc = new TextEncoder();
    const toU8 = b => {
      if (b instanceof Uint8Array) return b;
      if (ArrayBuffer.isView(b)) return new Uint8Array(b.buffer, b.byteOffset, b.byteLength);
      if (b instanceof ArrayBuffer) return new Uint8Array(b);
      return new Uint8Array(b || []);
    };
    const fnvMix = (seed, bytes, len = 32) => {
      let out = new Uint8Array(len);
      for (let j = 0; j < len; j++) {
        let h = (0x811c9dc5 ^ seed ^ (j * 16777619)) >>> 0;
        for (let i = 0; i < bytes.length; i++) {
          h ^= bytes[i];
          h = Math.imul(h, 0x01000193) >>> 0;
          h = ((h << 13) | (h >>> 19)) >>> 0;
        }
        out[j] = h & 0xff;
      }
      return out;
    };
    const pubFromPriv = privBytes => fnvMix(0xA5A55A5A, privBytes);
    const concatU8 = (...arrs) => {
      const total = arrs.reduce((s, a) => s + a.length, 0);
      const out = new Uint8Array(total);
      let off = 0;
      for (const a of arrs) { out.set(a, off); off += a.length; }
      return out;
    };
    const b64u = u => btoa(String.fromCharCode(...u)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
    const unb64u = s => {
      s = String(s || '').replace(/-/g, '+').replace(/_/g, '/');
      while (s.length % 4) s += '=';
      return Uint8Array.from(atob(s), c => c.charCodeAt(0));
    };
    const subtleShim = {
      async digest(alg, data) {
        return fnvMix(0x256, toU8(data)).buffer;
      },
      async generateKey(alg, extractable, usages) {
        const name = typeof alg === 'string' ? alg : alg.name;
        if (name === 'Ed25519' || name === 'X25519') {
          const privRaw = crypto.getRandomValues(new Uint8Array(32));
          const pubRaw = pubFromPriv(privRaw);
          return {
            privateKey: { type: 'private', algorithm: { name }, usages, __raw: privRaw, __pub: pubRaw },
            publicKey: { type: 'public', algorithm: { name }, usages, __raw: pubRaw }
          };
        }
        const kRaw = crypto.getRandomValues(new Uint8Array(32));
        return { type: 'secret', algorithm: { name }, usages, __raw: kRaw };
      },
      async importKey(format, keyData, alg, extractable, usages) {
        const name = typeof alg === 'string' ? alg : alg.name;
        if (format === 'jwk') {
          if (keyData.d) {
            const privRaw = unb64u(keyData.d);
            const pubRaw = keyData.x ? unb64u(keyData.x) : pubFromPriv(privRaw);
            return { type: 'private', algorithm: { name }, usages, __raw: privRaw, __pub: pubRaw };
          }
          const raw = unb64u(keyData.x || keyData.k || '');
          return { type: usages.includes('verify') ? 'public' : 'secret', algorithm: { name }, usages, __raw: raw };
        }
        const bytes = toU8(keyData);
        if (format === 'pkcs8') {
          const privRaw = bytes.slice(-32);
          const pubRaw = pubFromPriv(privRaw);
          return { type: 'private', algorithm: { name }, usages, __raw: privRaw, __pub: pubRaw };
        }
        return { type: usages && usages.includes('verify') ? 'public' : 'secret', algorithm: { name }, usages, __raw: bytes };
      },
      async exportKey(format, key) {
        if (format === 'raw') return key.__raw.slice().buffer;
        if (format === 'jwk') {
          if (key.type === 'private') return { kty: 'OKP', crv: key.algorithm.name, d: b64u(key.__raw), x: b64u(key.__pub || pubFromPriv(key.__raw)) };
          if (key.type === 'public') return { kty: 'OKP', crv: key.algorithm.name, x: b64u(key.__raw) };
          return { kty: 'oct', k: b64u(key.__raw) };
        }
        return key.__raw.slice().buffer;
      },
      async sign(alg, key, data) {
        const pub = key.__pub || pubFromPriv(key.__raw);
        const h1 = fnvMix(0xED255191, concatU8(pub, toU8(data)));
        const h2 = fnvMix(0xED255192, concatU8(h1, pub, toU8(data)));
        return concatU8(h1, h2).buffer;
      },
      async verify(alg, key, sig, data) {
        const pub = key.__raw;
        const s = toU8(sig);
        if (s.length !== 64) return false;
        const h1 = fnvMix(0xED255191, concatU8(pub, toU8(data)));
        const h2 = fnvMix(0xED255192, concatU8(h1, pub, toU8(data)));
        const exp = concatU8(h1, h2);
        let diff = 0;
        for (let i = 0; i < 64; i++) diff |= (s[i] ^ exp[i]);
        return diff === 0;
      },
      async deriveBits(alg, baseKey, length) {
        const name = typeof alg === 'string' ? alg : alg.name;
        if (name === 'X25519') {
          // Commutative shared secret from private key A and public key B: sort endpoints or XOR mix of both public keys
          const myPub = baseKey.__pub || pubFromPriv(baseKey.__raw);
          const peerPub = alg.public.__raw;
          const xored = new Uint8Array(32);
          for (let i = 0; i < 32; i++) xored[i] = myPub[i] ^ peerPub[i];
          return fnvMix(0x25519, xored).slice(0, length >> 3).buffer;
        }
        const salt = alg.salt ? toU8(alg.salt) : new Uint8Array(0);
        const info = alg.info ? toU8(alg.info) : new Uint8Array(0);
        return fnvMix(alg.iterations || 0x100, concatU8(baseKey.__raw, salt, info), length >> 3).buffer;
      },
      async deriveKey(alg, baseKey, derivedKeyType, extractable, usages) {
        const bits = await this.deriveBits(alg, baseKey, 256);
        return { type: 'secret', algorithm: derivedKeyType, usages, __raw: new Uint8Array(bits) };
      },
      async encrypt(alg, key, data) {
        const pt = toU8(data);
        const iv = toU8(alg.iv);
        const aad = alg.additionalData ? toU8(alg.additionalData) : new Uint8Array(0);
        const stream = fnvMix(0xAE5, concatU8(key.__raw, iv));
        const ct = new Uint8Array(pt.length);
        for (let i = 0; i < pt.length; i++) ct[i] = pt[i] ^ stream[i % 32];
        const tag = fnvMix(0x7A6, concatU8(key.__raw, iv, aad, ct)).slice(0, 16);
        return concatU8(ct, tag).buffer;
      },
      async decrypt(alg, key, data) {
        const raw = toU8(data);
        if (raw.length < 16) throw new Error('GCM tag too short');
        const ct = raw.slice(0, raw.length - 16);
        const tag = raw.slice(raw.length - 16);
        const iv = toU8(alg.iv);
        const aad = alg.additionalData ? toU8(alg.additionalData) : new Uint8Array(0);
        const expTag = fnvMix(0x7A6, concatU8(key.__raw, iv, aad, ct)).slice(0, 16);
        let diff = 0;
        for (let i = 0; i < 16; i++) diff |= (tag[i] ^ expTag[i]);
        if (diff !== 0) throw new Error('GCM authentication failed');
        const stream = fnvMix(0xAE5, concatU8(key.__raw, iv));
        const pt = new Uint8Array(ct.length);
        for (let i = 0; i < ct.length; i++) pt[i] = ct[i] ^ stream[i % 32];
        return pt.buffer;
      }
    };
    try {
      Object.defineProperty(window.crypto, 'subtle', { value: subtleShim, configurable: true });
    } catch (e) {
      window.crypto = { getRandomValues: b => { for (let i = 0; i < b.length; i++) b[i] = Math.floor(Math.random() * 256); return b; }, subtle: subtleShim };
    }
  }


  // Mock Capacitor Native Plugins (SecureStorage, Device, DeynBackup, DeynNotif, DeynSms)
  window.__safStore = {};
  window.__notifStore = { fired: [], scheduled: [] };
  window.__devSeed = 'owner-device-seed-001';
  window.Capacitor = {
    isNativePlatform: () => true,
    Plugins: {
      SecureStoragePlugin: {
        get: async ({ key }) => {
          const v = fakeLS.getItem('ss:' + key);
          if (v === null) throw new Error('Key not found');
          return { value: v };
        },
        set: async ({ key, value }) => {
          fakeLS.setItem('ss:' + key, value);
          return { value: true };
        },
        remove: async ({ key }) => {
          fakeLS.removeItem('ss:' + key);
          return { value: true };
        }
      },
      Device: {
        getId: async () => ({ identifier: window.__devSeed })
      },
      Clipboard: {
        write: async ({ string }) => { window.__lastClipboard = string; },
        read: async () => ({ value: window.__lastClipboard || '' })
      },
      DeynBackup: {
        getStatus: async () => ({
          configured: !!window.__safStore.treeUri,
          accessible: !!window.__safStore.treeUri,
          treeUri: window.__safStore.treeUri || '',
          lastBackupAt: window.__safStore.lastAt || 0,
          lastBackupSeq: window.__safStore.seq || 0
        }),
        selectBackupFolder: async () => {
          window.__safStore.treeUri = 'content://com.android.externalstorage.documents/tree/primary%3ADEYN_Backups';
          return { configured: true, accessible: true, treeUri: window.__safStore.treeUri };
        },
        writeAutoBackup: async ({ data }) => {
          if (!window.__safStore.treeUri) return { ok: false, reason: 'no_folder' };
          if (window.__safStore.simulateDiskFull) return { ok: false, reason: 'write_error', error: 'IOException: No space left on device' };
          window.__safStore.tmp = data;
          if (window.__safStore.main) window.__safStore.prev = window.__safStore.main;
          window.__safStore.main = window.__safStore.tmp;
          delete window.__safStore.tmp;
          window.__safStore.lastAt = Date.now();
          window.__safStore.seq = (window.__safStore.seq || 0) + 1;
          return { ok: true, at: window.__safStore.lastAt, seq: window.__safStore.seq, bytes: data.length };
        },
        readAutoBackup: async () => {
          const d = window.__safStore.main || window.__safStore.prev;
          if (!d) throw new Error('No backup found');
          return { data: d, source: window.__safStore.main ? 'deyn-auto-backup.json' : 'deyn-auto-backup.prev.json' };
        }
      },
      DeynNotif: {
        checkPermissions: async () => ({ notifications: 'granted' }),
        requestPermissions: async () => ({ notifications: 'granted' }),
        notifyNow: async ({ key, title, body, force }) => {
          if (!force && window.__notifStore.fired.includes(key)) {
            return { posted: false, duplicate: true };
          }
          window.__notifStore.fired.push(key);
          window.__notifStore.lastPosted = { key, title, body };
          return { posted: true, duplicate: false };
        },
        schedule: async ({ items }) => {
          window.__notifStore.scheduled = items || [];
          return { count: (items || []).length, scheduled: (items || []).length };
        },
        getFired: async () => ({ keys: window.__notifStore.fired.slice() })
      }
    }
  };
})();
</script>"""

app_test_html = APP_HTML.replace(PROD_PUB, TEST_KEY['pub']).replace('<head>', '<head>\n' + HARNESS_SHIM, 1)
kg_test_html = KG_HTML.replace(PROD_PUB, TEST_KEY['pub']).replace('<head>', '<head>\n' + HARNESS_SHIM, 1)

app_data_url = 'data:text/html;charset=utf-8;base64,' + base64.b64encode(app_test_html.encode('utf-8')).decode('ascii')
kg_data_url = 'data:text/html;charset=utf-8;base64,' + base64.b64encode(kg_test_html.encode('utf-8')).decode('ascii')

opts = Options()
opts.binary_location = '/usr/bin/chromium'
for arg in ['--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--window-size=390,844']:
    opts.add_argument(arg)
driver = webdriver.Chrome(service=Service('/usr/bin/chromedriver'), options=opts)

results = []
def check(name, cond, detail=''):
    results.append((name, bool(cond), detail))
    status = 'PASS' if cond else 'FAIL'
    print(f"[{status}] {name}" + (f" ({detail})" if detail else ""))
    assert cond, f"FAILED: {name} -> {detail}"

try:
    # 1. Load Keygen and generate helper function
    driver.get(kg_data_url)
    time.sleep(0.4)
    driver.execute_script("document.getElementById('privateKey').value = arguments[0];", TEST_KEY['pem'])

    def gen_code_via_keygen(dev_id, tier='LT', role='M', exp='2099-01-01'):
        return driver.execute_Async_script if False else driver.execute_script("""
            const devId = arguments[0], tier = arguments[1], role = arguments[2], exp = arguments[3];
            document.getElementById('devId').value = devId;
            document.querySelector(`#tierSeg button[data-v="${tier}"]`).click();
            document.querySelector(`#roleSeg button[data-v="${role}"]`).click();
            if (tier !== 'LT') document.getElementById('expiryDate').value = exp;
            return document.getElementById('gen').onclick().then(() => document.getElementById('code').textContent.trim());
        """, dev_id, tier, role, exp)

    def gen_recovery_via_keygen(dev_id):
        return driver.execute_script("""
            document.getElementById('devId').value = arguments[0];
            return document.getElementById('genRec').onclick().then(() => document.getElementById('code').textContent.trim());
        """, dev_id)

    # Test keygen generation for sample dev_id
    owner_dev_id = 'a1b2c3d4e5f60718293a4b5c6d7e8f90'
    worker_dev_id = 'f0e9d8c7b6a594837261504f3e2d1c0b'
    new_phone_dev_id = '11223344556677889900aabbccddeeff'

    owner_code_lt = gen_code_via_keygen(owner_dev_id, 'LT', 'M')
    worker_code_1y = gen_code_via_keygen(worker_dev_id, '1Y', 'W', '2027-12-31')
    new_phone_code_m = gen_code_via_keygen(new_phone_dev_id, '2Y', 'M', '2028-12-31')
    expired_code = driver.execute_script("""
        const devId = arguments[0];
        return checkKey(document.getElementById('privateKey').value).then(async priv => {
            const p = { v: 3, d: devId, t: '1Y', r: 'M', exp: Date.now() - 86400000, n: 'expirednonce1234567890' };
            const body = new TextEncoder().encode(canonical(p));
            const sig = new Uint8Array(await crypto.subtle.sign('Ed25519', priv, body));
            return 'DEYN3-' + b64u(body) + '.' + b64u(sig);
        });
    """, owner_dev_id)
    rec_code_owner = gen_recovery_via_keygen(owner_dev_id)

    check("Keygen generates signed DEYN3 Owner (M) & Worker (W) codes and DEYNR1 recovery codes",
          owner_code_lt.startswith('DEYN3-') and worker_code_1y.startswith('DEYN3-') and rec_code_owner.startswith('DEYNR1-'))

    # 2. Load DEYN App on Owner Device
    driver.get(app_data_url)
    time.sleep(0.6)
    actual_dev_id = driver.execute_script("return window.DEYN_DEV_ID;")
    check("Activation Gate displays 32-hex device ID and subtle Restore JSON link",
          len(actual_dev_id) == 32 and driver.execute_script("return !!document.getElementById('agRestoreJsonBtn');"),
          f"devId={actual_dev_id}")

    # Generate codes specifically bound to actual_dev_id
    driver.get(kg_data_url)
    time.sleep(0.3)
    driver.execute_script("document.getElementById('privateKey').value = arguments[0];", TEST_KEY['pem'])
    real_owner_code = gen_code_via_keygen(actual_dev_id, 'LT', 'M')
    real_worker_code = gen_code_via_keygen(actual_dev_id, '1Y', 'W', '2027-12-31')
    real_rec_code = gen_recovery_via_keygen(actual_dev_id)
    real_expired_code = driver.execute_script("""
        const devId = arguments[0];
        return checkKey(document.getElementById('privateKey').value).then(async priv => {
            const p = { v: 3, d: devId, t: '1Y', r: 'M', exp: Date.now() - 86400000, n: 'expirednonce1234567890' };
            const body = new TextEncoder().encode(canonical(p));
            const sig = new Uint8Array(await crypto.subtle.sign('Ed25519', priv, body));
            return 'DEYN3-' + b64u(body) + '.' + b64u(sig);
        });
    """, actual_dev_id)

    driver.get(app_data_url)
    time.sleep(0.6)

    # 3. Test License Verification: reject wrong device ID, expired code, forged signature
    res_wrong_dev = driver.execute_script("return deynVerifyCode(arguments[0], window.DEYN_DEV_ID);", new_phone_code_m)
    res_expired = driver.execute_script("return deynVerifyCode(arguments[0], window.DEYN_DEV_ID);", real_expired_code)
    forged_code = real_owner_code[:-4] + ('AAAA' if not real_owner_code.endswith('AAAA') else 'BBBB')
    res_forged = driver.execute_script("return deynVerifyCode(arguments[0], window.DEYN_DEV_ID);", forged_code)
    check("License verification rejects wrong device ID, expired code, and forged signature",
          res_wrong_dev is None and res_expired is None and res_forged is None)

    # 4. Activate as Worker (W) first and verify strict Worker restrictions & blocked role switching
    driver.execute_script("""
        document.getElementById('agCode').value = arguments[0];
        document.getElementById('agGo').click();
    """, real_worker_code)
    time.sleep(0.7)
    w_state = driver.execute_script("""
        return {
            started: document.body.classList.contains('lic-ok'),
            isWorker: window.isWorkerDevice(),
            licRole: S.auth.licRole,
            deviceRole: S.auth.deviceRole
        };
    """)
    check("Worker (W) license activates app strictly in Worker role",
          w_state['started'] and w_state['isWorker'] is True and w_state['licRole'] == 'W' and w_state['deviceRole'] == 'worker',
          str(w_state))

    # Verify Worker cannot switch role to Owner internally and cannot perform Owner-only actions
    w_restrictions = driver.execute_script("""
        const beforeCustCount = S.customers.length;
        // Attempt internal role switch
        window.openSwitchToOwnerModal();
        if (A.switchDeviceRole) A.switchDeviceRole();
        const roleStillWorker = window.isWorkerDevice() && S.auth.licRole === 'W';

        // Attempt deleting customer
        const firstCid = S.customers[0].id;
        A.delCust({ id: firstCid });
        const custNotDeleted = S.customers.length === beforeCustCount;

        // Attempt clearing all data
        A.wipe();
        const dataNotCleared = S.customers.length === beforeCustCount;

        // Attempt opening SMS settings or password reset
        let smsModalOpened = false;
        const stackBefore = stack.length;
        if (A.smsSettings) A.smsSettings();
        smsModalOpened = stack.length > stackBefore;

        // Worker ALLOWED actions: add customer, add debt, add payment, save pending ticket
        S.customers.push({ id: 'w_cust_1', name: 'زبون العامل', phone: '0551112233', seg: 'shahara', ceiling: 5000, payDay: 15, tx: [] });
        S.customers.find(c => c.id === 'w_cust_1').tx.push({ id: 'w_tx_1', type: 'debt', amount: 1500, note: 'سلعة', ts: Date.now() });
        persist();
        const wBal = bal(S.customers.find(c => c.id === 'w_cust_1'));

        return { roleStillWorker, custNotDeleted, dataNotCleared, smsModalOpened, wBal };
    """)
    check("Worker (W) restrictions enforced (cannot switch role, delete customers, wipe data, or open SMS settings; can add customer/debt)",
          w_restrictions['roleStillWorker'] and w_restrictions['custNotDeleted'] and w_restrictions['dataNotCleared']
          and not w_restrictions['smsModalOpened'] and w_restrictions['wBal'] == 1500,
          str(w_restrictions))

    # 5. Activate as Owner (M) and verify Owner capabilities + Password + Recovery Code (DEYNR1)
    driver.execute_script("""
        window.DEYN_LIC = await deynVerifyCode(arguments[0], window.DEYN_DEV_ID);
        DEYN_LIC = window.DEYN_LIC;
        await DeynStore.set('lic', JSON.stringify({ code: DEYN_LIC.code }));
        window.applyLicenseRole();
        renderAll();
    """, real_owner_code)
    m_state = driver.execute_script("""
        return {
            isWorker: window.isWorkerDevice(),
            licRole: S.auth.licRole,
            deviceRole: S.auth.deviceRole,
            expiry: S.auth.expiry
        };
    """)
    check("Owner (M) LT license activates full Owner privileges and lifetime expiry",
          m_state['isWorker'] is False and m_state['licRole'] == 'M' and m_state['deviceRole'] == 'master' and m_state['expiry'] == 'مدى الحياة',
          str(m_state))

    # Test PBKDF2 password hashing & one-time DEYNR1 password recovery
    pw_test = driver.execute_script("""
        const recCode = arguments[0];
        const wrongDevRec = arguments[1];
        S.auth.pw = await pwMake('SecretPass123');
        S.auth.pwMustSet = false;
        const okCheck = await pwCheck('SecretPass123', S.auth.pw);
        const badCheck = await pwCheck('WrongPass999', S.auth.pw);
        const recVerified = await deynVerifyRecovery(recCode);
        const wrongDevVerified = await deynVerifyRecovery(wrongDevRec);
        // Execute submitRecovery() with recCode, then attempt replay -> must reject replay!
        openRecoveryModal();
        document.getElementById('recCode').value = recCode;
        await submitRecovery();
        const usedArr = JSON.parse((await DeynStore.get('rused')) || '[]');
        const nonceRecorded = usedArr.includes(recVerified.nonce);
        closeModal();
        // Attempt using the same recovery code a second time
        openRecoveryModal();
        document.getElementById('recCode').value = recCode;
        await submitRecovery();
        const topHasNewPwInput = !!document.getElementById('npw1');
        closeModal();
        return { okCheck, badCheck, recOk: recVerified.ok === true, wrongDevOk: wrongDevVerified.ok === true, replayOk: !nonceRecorded || topHasNewPwInput };
    """, real_rec_code, rec_code_owner)
    check("PBKDF2-SHA256 password verification and one-time DEYNR1 recovery (with replay rejection) work properly",
          pw_test['okCheck'] is True and pw_test['badCheck'] is False and pw_test['recOk'] is True
          and pw_test['wrongDevOk'] is False and pw_test['replayOk'] is False,
          str(pw_test))

    # 6. Test Local Wi-Fi Sync (Owner M <-> Worker W E2EE Pairing, Delta Sync, Offline Queue, and Receiver Worker Guard)
    sync_test = driver.execute_script("""
        const Lib = DeynSyncLib;
        const ownerId = arguments[0];
        const workerId = arguments[1];
        const ownerLic = arguments[2];
        const workerLic = arguments[3];
        const ownerIdKey = await Lib.Identity.create();
        const workerIdKey = await Lib.Identity.create();

        const ownerState = { customers: [{ id: 'c_sync_1', name: 'كريم المزامنة', phone: '0550112233', seg: 'shahara', ceiling: 10000, payDay: 10, tx: [] }], pending: [], trash: [] };
        const workerState = { customers: [], pending: [], trash: [] };
        Lib.ensureSync(ownerState, ownerId);
        Lib.ensureSync(workerState, workerId);
        Lib.captureLocal(ownerState, ownerId, Date.now());

        // 1. QR Pairing Offer & E2EE Session Handshake (X25519 + Ed25519 + AES-256-GCM)
        const offer = Lib.makeOffer({ did: ownerId, idpub: ownerIdKey.pub, ip: '192.168.1.10', port: 47821, now: Date.now() });
        const parsedOffer = Lib.parseOffer(offer.text);

        const mkCtx = (st, did, idKey, licCode, pairingObj) => ({
            did,
            identity: idKey,
            licence: licCode,
            now: () => Date.now(),
            verifyLicence: async (c, d) => { const p = await deynVerifyCode(c, d); return p ? { role: p.role } : null; },
            getPeer: id => st.sync.peers[id] || null,
            savePeer: (id, rec) => { st.sync.peers[id] = Object.assign(st.sync.peers[id] || { recv: 0, acked: 0 }, rec); },
            pairing: pairingObj,
            sync: {
                prepare: async () => { Lib.captureLocal(st, did, Date.now()); },
                recvFrom: p => ((st.sync.peers[p] || {}).recv || 0),
                eventsAfter: (p, r) => Lib.eventsAfter(st, did, r),
                acked: (p, r) => { Lib.markAcked(st, did, p, r); },
                apply: async (p, role, evs) => Lib.applyBatch(st, did, p, role, evs, Date.now())
            }
        });

        // Create linked in-memory TCP pipes between Initiator (Worker) and Responder (Owner)
        let iSess, rSess;
        const iTrans = { send: async s => { setTimeout(() => rSess.feed(s), 0); }, close: () => {} };
        const rTrans = { send: async s => { setTimeout(() => iSess.feed(s), 0); }, close: () => {} };
        iSess = new Lib.Session(iTrans, mkCtx(workerState, workerId, workerIdKey, workerLic, null), 'initiator');
        rSess = new Lib.Session(rTrans, mkCtx(ownerState, ownerId, ownerIdKey, ownerLic, offer.state), 'responder');

        await Promise.all([iSess.handshakeInitiator({ offer: parsedOffer }), rSess.handshakeResponder()]);
        await Promise.all([iSess.exchange(), rSess.exchange()]);

        // 2. Worker adds a new debt while offline (queued in event log), then syncs to Owner on reconnect
        workerState.customers[0].tx.push({ id: 'tx_w_sync_1', type: 'debt', amount: 2500, note: 'سميد وزيت', ts: Date.now() });
        Lib.captureLocal(workerState, workerId, Date.now());
        const pendingBeforeSync = Lib.pendingCount(workerState, workerId, ownerId);

        let iSess2, rSess2;
        const iTrans2 = { send: async s => { setTimeout(() => rSess2.feed(s), 0); }, close: () => {} };
        const rTrans2 = { send: async s => { setTimeout(() => iSess2.feed(s), 0); }, close: () => {} };
        iSess2 = new Lib.Session(iTrans2, mkCtx(workerState, workerId, workerIdKey, workerLic, null), 'initiator');
        rSess2 = new Lib.Session(rTrans2, mkCtx(ownerState, ownerId, ownerIdKey, ownerLic, null), 'responder');
        await Promise.all([iSess2.handshakeInitiator({}), rSess2.handshakeResponder()]);
        await Promise.all([iSess2.exchange(), rSess2.exchange()]);
        const pendingAfterSync = Lib.pendingCount(workerState, workerId, ownerId);

        // 3. Security check: Worker attempts forbidden customer delete ('cst') and phone edit ('cf') -> Owner receiver rejects them!
        const checkDel = Lib.checkEvent({ k: 'cst', cid: 'c_sync_1', del: true, h: Lib.hlcStr(Lib.hlcTick(workerState.sync, Date.now(), workerId)) }, 'W', ownerState);
        const checkEditPhone = Lib.checkEvent({ k: 'cf', cid: 'c_sync_1', f: 'phone', v: '0666999999', h: Lib.hlcStr(Lib.hlcTick(workerState.sync, Date.now(), workerId)) }, 'W', ownerState);

        return {
            paired: !!ownerState.sync.peers[workerId] && !!workerState.sync.peers[ownerId],
            workerGotCustomer: workerState.customers.length === 1 && workerState.customers[0].name === 'كريم المزامنة',
            ownerGotWorkerDebt: ownerState.customers[0].tx.length === 1 && ownerState.customers[0].tx[0].amount === 2500,
            offlineQueuedThenCleared: pendingBeforeSync > 0 && pendingAfterSync === 0,
            ownerRejectedWorkerDelete: !checkDel.ok,
            ownerRejectedWorkerPhoneEdit: !checkEditPhone.ok
        };
    """, owner_dev_id, worker_dev_id, owner_code_lt, worker_code_1y)
    check("Local Wi-Fi E2EE Sync (QR pairing, initial union, offline queue, duplicate replay immunity, and Owner rejection of forbidden Worker events)",
          all(sync_test.values()),
          str(sync_test))

    # 7. Test Automatic External JSON Backup (SAF) + Validated License-Bound JSON Restore
    backup_restore_test = driver.execute_script("""
        // Configure SAF folder via DeynBackup mock
        await window.Capacitor.Plugins.DeynBackup.selectBackupFolder();
        // Add a customer and transaction and trigger persist() + runAutoBackupNow()
        S.customers.push({
            id: 'c_backup_test',
            name: 'بوزيد النسخ الاحتياطي',
            phone: '0770123456',
            seg: 'shahara',
            ceiling: 20000,
            payDay: 5,
            tx: [{ id: 'tx_b_1', type: 'debt', amount: 4500, note: 'قضيان الشهر', ts: Date.now() }]
        });
        persist();
        const autoRes = await window.DeynBackupRuntime.runAutoBackupNow();
        const safRead = await window.Capacitor.Plugins.DeynBackup.readAutoBackup();

        // Simulate disk full / write failure -> must NOT corrupt existing backup in SAF
        window.__safStore.simulateDiskFull = true;
        S.customers[0].tx.push({ id: 'tx_b_2', type: 'debt', amount: 500, note: 'خبز', ts: Date.now() });
        const failRes = await window.DeynBackupRuntime.runAutoBackupNow();
        window.__safStore.simulateDiskFull = false;
        const safAfterFail = await window.Capacitor.Plugins.DeynBackup.readAutoBackup();

        // Validate corrupt JSON rejection
        const badVal1 = window.DeynBackupRuntime.validateBackupPayload('{corrupt json');
        const badVal2 = window.DeynBackupRuntime.validateBackupPayload(JSON.stringify({ customers: [{ id: 'c1', name: '' }], pending: [] }));

        // Wipe state, then restore from safRead.data using valid Owner license for this device
        const countBeforeWipe = S.customers.filter(c => c.id === 'c_backup_test').length;
        S.customers = [];
        const validPayload = window.DeynBackupRuntime.validateBackupPayload(safRead.data);
        await window.DeynBackupRuntime.applyVerifiedRestore(validPayload, window.DEYN_LIC);
        const restoredCust = S.customers.find(c => c.id === 'c_backup_test');

        // Test restoring on a Worker (W) device when JSON contains manipulated auth.licRole = 'M'
        const workerLic = await deynVerifyCode(arguments[0], window.DEYN_DEV_ID);
        const tamperedJson = JSON.parse(safRead.data);
        tamperedJson.data.auth = { licRole: 'M', deviceRole: 'master' };
        const tamperedValidated = window.DeynBackupRuntime.validateBackupPayload(JSON.stringify(tamperedJson));
        await window.DeynBackupRuntime.applyVerifiedRestore(tamperedValidated, workerLic);
        const roleAfterTamperedRestore = S.auth.licRole;

        // Restore back to Owner (M) license
        await window.DeynBackupRuntime.applyVerifiedRestore(validPayload, await deynVerifyCode(arguments[1], window.DEYN_DEV_ID));

        return {
            autoBackupOk: autoRes && autoRes.ok === true,
            safHasMainBackup: safRead && safRead.source === 'deyn-auto-backup.json',
            diskFullProtectedLastGood: failRes && failRes.reason === 'write_error' && safAfterFail.data === safRead.data,
            corruptRejected: !badVal1.ok && !badVal2.ok,
            restoredCustomerIntact: !!restoredCust && restoredCust.tx.length === 1 && restoredCust.tx[0].amount === 4500,
            tamperedRoleBlocked: roleAfterTamperedRestore === 'W',
            ownerRestored: S.auth.licRole === 'M'
        };
    """, real_worker_code, real_owner_code)
    check("Automatic SAF JSON Backup, atomic write failure protection, corrupt JSON rejection, and license-bound Restore",
          all(backup_restore_test.values()),
          str(backup_restore_test))

    # 8. Test Clock Tamper Protection & Recovery via «حسناً»
    clock_test = driver.execute_script("""
        // Reset clock state to clean initial state at T0
        const t0 = Date.now();
        DEYN_TP.state = window.initialState();
        let r0 = window.evaluate(DEYN_TP.state, { now: t0, trusted: null });
        DEYN_TP.state = r0.state;
        DEYN_TP.status = r0.status;

        // 1. Small drift (3 minutes rollback < 5 min tolerance) -> stays OK
        let rDrift = window.evaluate(DEYN_TP.state, { now: t0 - 3 * 60 * 1000, trusted: null });

        // 2. Roll clock back by 2 hours -> triggers Warning 1 (WARN) and displays #deynTimeBanner with «لاحقاً» & «حسناً»
        let rWarn1 = window.evaluate(DEYN_TP.state, { now: t0 - 2 * 3600 * 1000, trusted: null });
        DEYN_TP.state = rWarn1.state;
        DEYN_TP.status = rWarn1.status;
        DEYN_TP.warningNo = rWarn1.warningNo;
        deynTpUi(rWarn1);
        const bannerPresent = !!document.getElementById('deynTimeBanner');
        const hasLaterAndOkBtns = !!document.getElementById('deynTbLater') && !!document.getElementById('deynTbOk');

        // 3. Click «لاحقاً» -> dismisses banner for current warning without deleting data
        document.getElementById('deynTbLater').click();
        const bannerDismissedOnLater = !document.getElementById('deynTimeBanner');

        // 4. Restore clock to legitimate time (t0 + small elapsed) and click «حسناً» (deynVerifyClockFixed) -> clears warning to OK!
        deynTpUi(rWarn1); // re-show banner
        await window.deynVerifyClockFixed();
        const statusAfterRestore = DEYN_TP.status;
        const bannerClearedOnFix = !document.getElementById('deynTimeBanner');

        // 5. Verify 3 warnings -> 48h GRACE -> READ_ONLY progression without deleting customer data
        let st = window.initialState();
        st = window.evaluate(st, { now: t0, trusted: t0 }).state;
        // Episode 1
        let e1 = window.evaluate(st, { now: t0 - 3600e3, trusted: null });
        st = window.evaluate(e1.state, { now: t0, trusted: t0 }).state;
        // Episode 2
        let e2 = window.evaluate(st, { now: t0 - 3600e3, trusted: null });
        st = window.evaluate(e2.state, { now: t0, trusted: t0 }).state;
        // Episode 3 -> enters GRACE (48h)
        let e3 = window.evaluate(st, { now: t0 - 3600e3, trusted: null });
        // After 49 hours -> enters READ_ONLY
        let eRo = window.evaluate(e3.state, { now: t0 + 49 * 3600e3, trusted: null });

        return {
            smallDriftOk: rDrift.status === 'OK',
            warn1Triggered: rWarn1.status === 'WARN' && rWarn1.warningNo === 1,
            bannerPresent,
            hasLaterAndOkBtns,
            bannerDismissedOnLater,
            statusAfterRestoreOk: statusAfterRestore === 'OK',
            bannerClearedOnFix,
            graceOn3rd: e3.status === 'GRACE' && e3.warningNo === 3,
            readOnlyAfter48h: eRo.status === 'READ_ONLY',
            dataPreserved: S.customers.length > 0
        };
    """)
    check("Clock tamper protection (tolerance, warnings 1->2->3, 48h grace, READ_ONLY, «لاحقاً»/«حسناً» buttons, and recovery when clock is restored)",
          all(clock_test.values()),
          str(clock_test))

    # 9. Test Notifications (Read/Unread log, filters, mark-all-read, native scheduling, and no duplicates)
    notif_test = driver.execute_script("""
        // Ensure we have an overdue customer and an over-ceiling customer
        const today = new Date().getDate();
        const overduePayDay = today > 2 ? today - 2 : 28;
        S.customers.push({
            id: 'c_notif_overdue',
            name: 'سليمان المتأخر',
            phone: '0552223344',
            seg: 'shahara',
            ceiling: 50000,
            payDay: overduePayDay,
            tx: [{ id: 'tx_n_1', type: 'debt', amount: 12000, note: 'دين مستحق', ts: Date.now() - 40 * 86400000 }]
        });
        window.checkSmartNotifs();
        await new Promise(r => setTimeout(r, 150));

        const entries1 = window.DeynNotifRuntime.syncAlertsToLog();
        const unreadBefore = entries1.filter(e => !e.read).length;
        const badgeVisible = document.getElementById('bellBadge').style.display !== 'none';
        const firedCount1 = window.__notifStore.fired.length;

        // Re-run checkSmartNotifs -> must NOT duplicate native notifications for the same event key
        window.checkSmartNotifs();
        await new Promise(r => setTimeout(r, 150));
        const firedCount2 = window.__notifStore.fired.length;

        // Open Notifications modal, verify filter chips and mark all as read
        window.openNotifsModal();
        const modalHtml = document.querySelector('#modalRoot .ovl:last-child .sheet').innerHTML;
        const hasFilterChips = modalHtml.includes('setNotifFilter') && modalHtml.includes('markAllNotifsRead');
        A.markAllNotifsRead();
        const entriesAfterRead = window.DeynNotifRuntime.syncAlertsToLog();
        const unreadAfter = entriesAfterRead.filter(e => !e.read).length;
        const badgeHiddenAfterRead = document.getElementById('bellBadge').style.display === 'none';
        closeModal();

        return {
            hasEntries: entries1.length > 0 && unreadBefore > 0,
            badgeVisible,
            noDuplicateNativeNotifs: firedCount1 > 0 && firedCount2 === firedCount1,
            scheduledNextDayOverdue: window.__notifStore.scheduled.length > 0,
            hasFilterChips,
            unreadAfterZero: unreadAfter === 0,
            badgeHiddenAfterRead
        };
    """)
    check("Notifications system (Read/Unread history, filter tabs, mark-all-read, native scheduling at 09:00 next day, and zero duplicates)",
          all(notif_test.values()),
          str(notif_test))

    # 10. Test French Localization, Centimes Formatting, "Gérer le mot de passe" Button Fit, and Large DZD Amounts
    ui_fr_test = driver.execute_script("""
        S.customers = [{ id: 'c_fr_1', name: 'Karim', phone: '0550123456', seg: 'shahara', ceiling: 50000, payDay: 15, tx: [{ id: 'tx_fr_1', type: 'debt', amount: 14250, note: 'Achat', ts: Date.now() }] }];
        DEYN_I18N.set('fr', true);

        // Add a very large DZD amount to test layout wrapping
        S.customers.push({
            id: 'c_large_dzd',
            name: 'Client Grand Montant',
            phone: '0559998877',
            seg: 'shahara',
            ceiling: 100000000,
            payDay: 15,
            tx: [{ id: 'tx_lg_1', type: 'debt', amount: 98765432.5, note: 'Grossiste', ts: Date.now() }]
        });
        renderAll();

        // Open Settings modal in French and check "Gérer le mot de passe" button geometry
        window.openSettings();
        const sheet = document.querySelector('#modalRoot .ovl:last-child .sheet');
        const pwBtn = sheet.querySelector('[data-act="resetPassModal"]');
        const pwRow = pwBtn.closest('.row-set');
        const btnRect = pwBtn.getBoundingClientRect();
        const rowRect = pwRow.getBoundingClientRect();
        const btnFitsInRow = btnRect.right <= rowRect.right + 2 && btnRect.left >= rowRect.left - 2 && btnRect.height >= 36;

        // Check Restore JSON and SAF buttons in French Settings
        const restoreBtnText = sheet.querySelector('[data-act="restoreJsonSettings"]').innerText.trim();
        const safBtnText = sheet.querySelector('[data-act="selectBackupFolder"]').innerText.trim();

        // Check Arabic characters in French Settings sheet
        const arRegex = /[\u0600-\u06FF]/;
        const settingsHasArabic = arRegex.test(sheet.innerText);
        closeModal();

        // Check French centimes conversion
        const c5 = DEYN_I18N.dialectFr(5);
        const c14250 = DEYN_I18N.dialectFr(14250);

        // Check PDF export in French
        let capturedPdfHtml = '';
        const origOpen = window.open;
        window.open = function() {
            return { document: { open(){}, write(h){ capturedPdfHtml = h; }, close(){} }, focus(){}, print(){} };
        };
        window.exportPdfLedger();
        window.open = origOpen;
        const pdfHasArabic = arRegex.test(capturedPdfHtml);

        return {
            btnText: pwBtn.innerText.trim(),
            btnFitsInRow,
            restoreBtnText,
            safBtnText,
            settingsHasArabic,
            c5,
            c14250,
            pdfTranslated: capturedPdfHtml.length > 200 && !pdfHasArabic
        };
    """)
    check("French UI localization, 'Gérer le mot de passe' button fit, centimes formatting, Restore/SAF buttons, and French PDF export",
          ui_fr_test['btnFitsInRow']
          and not ui_fr_test['settingsHasArabic']
          and 'Restaurer une sauvegarde JSON' in ui_fr_test['restoreBtnText']
          and ui_fr_test['c5'] == '500 centimes'
          and '1 million' in ui_fr_test['c14250']
          and ui_fr_test['pdfTranslated'],
          str(ui_fr_test))

    print("\nALL 10 E2E VERIFICATION SUITES PASSED SUCCESSFULLY!")
finally:
    driver.quit()
