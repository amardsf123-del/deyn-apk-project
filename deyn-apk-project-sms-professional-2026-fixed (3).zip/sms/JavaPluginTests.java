package com.deyn.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import java.io.File;
import org.json.JSONObject;

public class JavaPluginTests {
    public static void main(String[] args) throws Exception {
        Context ctx = new Context();
        File safDir = new File("/tmp/java_verify/saf_tree");
        if (safDir.exists()) {
            for (File f : safDir.listFiles()) f.delete();
        }
        safDir.mkdirs();

        // 1a. Verify no_folder when SAF URI is not configured yet
        DeynBackupPlugin backup = new DeynBackupPlugin();
        String json1 = "{\"format\":\"DEYN-BACKUP-V2\",\"version\":2,\"data\":{\"customers\":[{\"id\":\"c1\",\"name\":\"أحمد\"}],\"pending\":[]}}";
        PluginCall writeNoFolder = new PluginCall().put("data", json1);
        backup.writeAutoBackup(writeNoFolder);
        assert writeNoFolder.resolved != null && !writeNoFolder.resolved.optBoolean("ok")
            && "no_folder".equals(writeNoFolder.resolved.optString("reason")) : "Expected no_folder before SAF selection";

        // 1b. Configure SAF tree URI and verify atomic write (.tmp -> fsync -> readback -> .prev -> .json)
        SharedPreferences.MEM.put("tree_uri", "content://tree/deyn");
        PluginCall write1 = new PluginCall().put("data", json1);
        backup.writeAutoBackup(write1);
        Thread.sleep(250);
        assert write1.resolved != null && write1.resolved.optBoolean("ok") : "First atomic backup write failed: " + write1.resolved;

        File mainFile = new File(safDir, "deyn-auto-backup.json");
        File prevFile = new File(safDir, "deyn-auto-backup.prev.json");
        File tmpFile = new File(safDir, "deyn-auto-backup.tmp.json");
        assert mainFile.isFile() : "Main backup file missing";
        assert !tmpFile.exists() : "Temp file should be cleaned up after atomic move";

        String json2 = "{\"format\":\"DEYN-BACKUP-V2\",\"version\":2,\"data\":{\"customers\":[{\"id\":\"c1\",\"name\":\"أحمد\"},{\"id\":\"c2\",\"name\":\"سعيد\"}],\"pending\":[]}}";
        PluginCall write2 = new PluginCall().put("data", json2);
        backup.writeAutoBackup(write2);
        Thread.sleep(250);
        assert write2.resolved != null && write2.resolved.optBoolean("ok") : "Second atomic backup write failed";
        assert prevFile.isFile() : "Previous backup (.prev.json) should exist after second write";

        // Attempt writing invalid/corrupt payload -> must fail without corrupting mainFile
        PluginCall writeBad = new PluginCall().put("data", "NOT_JSON_AT_ALL");
        backup.writeAutoBackup(writeBad);
        Thread.sleep(200);
        assert writeBad.resolved != null && !writeBad.resolved.optBoolean("ok") : "Invalid JSON should be rejected";

        PluginCall readCall = new PluginCall();
        backup.readAutoBackup(readCall);
        assert readCall.resolved != null && json2.equals(readCall.resolved.optString("data")) : "Main backup file content was not preserved cleanly";
        System.out.println("PASS: DeynBackupPlugin SAF atomic write (.tmp -> fsync -> readback -> .prev -> .json) & corruption protection verified.");

        // 2. Test DeynNotifPlugin deduplication, scheduling, and BootReceiver
        DeynNotifPlugin notif = new DeynNotifPlugin();
        String nKey = "overdue|c1|2026-11|10";
        boolean firstPost = DeynNotifPlugin.postOnce(ctx, nKey, "DEYN — أحمد", "متأخر بـ 1 يوم", false);
        boolean secondPost = DeynNotifPlugin.postOnce(ctx, nKey, "DEYN — أحمد", "متأخر بـ 1 يوم", false);
        assert firstPost : "First notification post should succeed";
        assert !secondPost : "Duplicate notification with same key must be suppressed";
        assert DeynNotifPlugin.wasFired(ctx, nKey) : "wasFired should return true";

        JSArray schedArr = new JSArray();
        JSONObject item = new JSONObject();
        item.put("key", "overdue|c2|2026-11|15");
        item.put("title", "DEYN — سعيد");
        item.put("body", "متأخر بـ 1 يوم");
        item.put("at", System.currentTimeMillis() + 3600_000L);
        schedArr.put(item);
        PluginCall schedCall = new PluginCall().put("items", schedArr);
        notif.schedule(schedCall);
        assert schedCall.resolved != null && schedCall.resolved.optInt("scheduled") == 1 : "Expected 1 scheduled notification";

        DeynNotifPlugin.NotifBootReceiver bootReceiver = new DeynNotifPlugin.NotifBootReceiver();
        bootReceiver.onReceive(ctx, new Intent(Intent.ACTION_BOOT_COMPLETED));
        System.out.println("PASS: DeynNotifPlugin deduplication, WorkManager scheduling, and BootReceiver rescheduling verified.");

        // 3. Test DeynSmsPlugin multipart division and per-part status state machine
        String longAr = "السلام عليكم أحمد، تذكير ودي من محل الأمانة بخصوص الرصيد المتبقي 14500 دج المستحق يوم 10/11/2026، بارك الله فيكم وشكرًا لتعاملكم الطيب معنا.";
        DeynSmsPlugin.DispatchResult dr = DeynSmsPlugin.dispatchOnce(ctx, "msg-test-1", "+213550123456", longAr, false, 0L, 1);
        assert dr.dispatched : "Expected dispatched = true";
        assert dr.totalParts >= 2 : "Expected multipart Arabic message (>= 2 parts), got " + dr.totalParts;

        DeynSmsPlugin.SmsStatusReceiver smsReceiver = new DeynSmsPlugin.SmsStatusReceiver();
        long att = SharedPreferences.MEM.get("attempt_at_msg-test-1") instanceof Long
            ? (Long) SharedPreferences.MEM.get("attempt_at_msg-test-1") : 0L;
        for (int p = 0; p < dr.totalParts; p++) {
            Intent sentIntent = new Intent(DeynSmsPlugin.ACTION_SMS_SENT)
                .putExtra("id", "msg-test-1")
                .putExtra("partIndex", p)
                .putExtra("partsTotal", dr.totalParts)
                .putExtra("attemptAt", att);
            smsReceiver.setResultCode(android.app.Activity.RESULT_OK);
            smsReceiver.onReceive(ctx, sentIntent);
        }
        JSObject snapSent = DeynSmsPlugin.buildItemSnapshot(ctx.getSharedPreferences("deyn_sms_native", 0), "msg-test-1");
        assert "sent_to_network".equals(snapSent.optString("status")) : "Expected sent_to_network after all parts sent, got " + snapSent.optString("status");

        for (int p = 0; p < dr.totalParts; p++) {
            Intent delivIntent = new Intent(DeynSmsPlugin.ACTION_SMS_DELIVERED)
                .putExtra("id", "msg-test-1")
                .putExtra("partIndex", p)
                .putExtra("partsTotal", dr.totalParts)
                .putExtra("attemptAt", att);
            smsReceiver.setResultCode(android.app.Activity.RESULT_OK);
            smsReceiver.onReceive(ctx, delivIntent);
        }
        JSObject snapDeliv = DeynSmsPlugin.buildItemSnapshot(ctx.getSharedPreferences("deyn_sms_native", 0), "msg-test-1");
        assert "delivered".equals(snapDeliv.optString("status")) : "Expected delivered after all parts delivered, got " + snapDeliv.optString("status");
        System.out.println("PASS: DeynSmsPlugin multipart division and per-part BroadcastReceiver state machine verified.");
        System.exit(0);
    }
}
