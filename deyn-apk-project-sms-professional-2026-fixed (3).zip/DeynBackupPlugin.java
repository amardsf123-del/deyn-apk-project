package com.deyn.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Native Android backup & restore engine for DEYN using Storage Access Framework (SAF).
 * - Stores backups outside app-private storage (inside a user-chosen SAF directory with persistable URI permission)
 *   so backups survive app uninstallation or app-data clearing.
 * - Uses a serialized single-thread writer + two-phase atomic write (write to deyn-auto-backup.tmp.json, flush + fsync,
 *   verify read-back length & JSON integrity, then write/replace deyn-auto-backup.json and keep deyn-auto-backup.prev.json)
 *   so interrupted writes or full storage never corrupt the last good backup.
 */
@CapacitorPlugin(name = "DeynBackup")
public class DeynBackupPlugin extends Plugin {
    public static final String PREFS = "deyn_backup_prefs";
    public static final String KEY_TREE_URI = "tree_uri";
    public static final String KEY_LAST_SUCCESS_AT = "last_backup_at";
    public static final String KEY_LAST_ERROR = "last_backup_error";
    public static final String KEY_BACKUP_SEQ = "backup_seq";

    public static final String MAIN_FILE = "deyn-auto-backup.json";
    public static final String PREV_FILE = "deyn-auto-backup.prev.json";
    public static final String TEMP_FILE = "deyn-auto-backup.tmp.json";

    private static final Object WRITE_LOCK = new Object();
    private static final ExecutorService WRITE_EXEC = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "deyn-saf-backup"); t.setDaemon(true); return t; });
    private static volatile String pendingPayload = null;
    private static volatile boolean writeLoopRunning = false;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void getFolderStatus(PluginCall call) {
        Context c = getContext();
        SharedPreferences sp = prefs(c);
        String uriStr = sp.getString(KEY_TREE_URI, "");
        boolean hasPerm = false;
        if (uriStr != null && !uriStr.isEmpty()) {
            try {
                Uri treeUri = Uri.parse(uriStr);
                for (android.content.UriPermission p : c.getContentResolver().getPersistedUriPermissions()) {
                    if (p.getUri().equals(treeUri) && p.isReadPermission() && p.isWritePermission()) {
                        hasPerm = true;
                        break;
                    }
                }
            } catch (Exception ignored) {}
        }
        JSObject out = new JSObject();
        out.put("configured", hasPerm && uriStr != null && !uriStr.isEmpty());
        out.put("uri", uriStr == null ? "" : uriStr);
        out.put("lastBackupAt", sp.getLong(KEY_LAST_SUCCESS_AT, 0L));
        out.put("lastError", sp.getString(KEY_LAST_ERROR, ""));
        out.put("seq", sp.getLong(KEY_BACKUP_SEQ, 0L));
        call.resolve(out);
    }

    @PluginMethod
    public void selectBackupFolder(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, intent, "onFolderSelected");
    }

    @ActivityCallback
    private void onFolderSelected(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("Folder selection cancelled");
            return;
        }
        Uri treeUri = result.getData().getData();
        try {
            int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
            getContext().getContentResolver().takePersistableUriPermission(treeUri, flags);
            prefs(getContext()).edit()
                .putString(KEY_TREE_URI, treeUri.toString())
                .remove(KEY_LAST_ERROR)
                .commit();
            JSObject out = new JSObject();
            out.put("configured", true);
            out.put("uri", treeUri.toString());
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Could not persist folder permission: " + e.getMessage());
        }
    }

    @PluginMethod
    public void writeAutoBackup(final PluginCall call) {
        final String data = call.getString("data", "");
        if (data == null || data.trim().isEmpty()) {
            call.reject("Empty backup payload");
            return;
        }
        final Context context = getContext().getApplicationContext();
        String uriStr = prefs(context).getString(KEY_TREE_URI, "");
        if (uriStr == null || uriStr.isEmpty()) {
            JSObject out = new JSObject();
            out.put("ok", false);
            out.put("reason", "no_folder");
            call.resolve(out);
            return;
        }
        pendingPayload = data;
        WRITE_EXEC.execute(() -> {
            String snap = pendingPayload;
            if (snap == null) {
                JSObject out = new JSObject();
                out.put("ok", true);
                out.put("coalesced", true);
                call.resolve(out);
                return;
            }
            pendingPayload = null;
            JSObject res = writeSafelyToTree(context, snap);
            call.resolve(res);
        });
    }

    public static JSObject writeSafelyToTree(Context context, String jsonText) {
        synchronized (WRITE_LOCK) {
            SharedPreferences sp = prefs(context);
            String uriStr = sp.getString(KEY_TREE_URI, "");
            JSObject out = new JSObject();
            if (uriStr == null || uriStr.isEmpty()) {
                out.put("ok", false);
                out.put("reason", "no_folder");
                return out;
            }
            try {
                byte[] bytes = jsonText.getBytes(StandardCharsets.UTF_8);
                if (bytes.length < 20 || jsonText.charAt(0) != '{' || jsonText.charAt(jsonText.length() - 1) != '}') {
                    throw new IllegalArgumentException("Invalid JSON backup format");
                }
                Uri treeUri = Uri.parse(uriStr);
                ContentResolver cr = context.getContentResolver();
                Uri rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));

                // 1. Write to temporary file first and fsync
                Uri tmpUri = findOrCreateDocument(cr, treeUri, rootDocUri, TEMP_FILE, "application/json");
                if (tmpUri == null) throw new IllegalStateException("Could not create temporary backup file");
                writeAndSyncUri(cr, tmpUri, bytes);

                // 2. Verify read-back of temporary file before touching the main backup file
                byte[] readBack = readUriBytes(cr, tmpUri);
                if (readBack == null || readBack.length != bytes.length) {
                    throw new IllegalStateException("Temporary backup verification mismatch");
                }

                // 3. Copy previous main backup into .prev.json if main already exists
                Uri mainUri = findChildDocument(cr, treeUri, rootDocUri, MAIN_FILE);
                if (mainUri != null) {
                    byte[] prevBytes = readUriBytes(cr, mainUri);
                    if (prevBytes != null && prevBytes.length > 20) {
                        Uri prevUri = findOrCreateDocument(cr, treeUri, rootDocUri, PREV_FILE, "application/json");
                        if (prevUri != null) {
                            writeAndSyncUri(cr, prevUri, prevBytes);
                        }
                    }
                } else {
                    mainUri = findOrCreateDocument(cr, treeUri, rootDocUri, MAIN_FILE, "application/json");
                }
                if (mainUri == null) throw new IllegalStateException("Could not access main backup file");

                // 4. Write verified bytes to main backup file and fsync
                writeAndSyncUri(cr, mainUri, bytes);
                byte[] verifyMain = readUriBytes(cr, mainUri);
                if (verifyMain == null || verifyMain.length != bytes.length) {
                    throw new IllegalStateException("Main backup read-back verification failed");
                }

                // 5. Remove temporary file best-effort
                try { DocumentsContract.deleteDocument(cr, tmpUri); } catch (Exception ignored) {}

                long now = System.currentTimeMillis();
                long seq = sp.getLong(KEY_BACKUP_SEQ, 0L) + 1L;
                sp.edit()
                    .putLong(KEY_LAST_SUCCESS_AT, now)
                    .putLong(KEY_BACKUP_SEQ, seq)
                    .remove(KEY_LAST_ERROR)
                    .commit();

                out.put("ok", true);
                out.put("at", now);
                out.put("seq", seq);
                out.put("bytes", bytes.length);
                return out;
            } catch (Exception e) {
                String msg = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
                sp.edit().putString(KEY_LAST_ERROR, msg).commit();
                out.put("ok", false);
                out.put("reason", "write_error");
                out.put("error", msg);
                return out;
            }
        }
    }

    @PluginMethod
    public void readAutoBackup(PluginCall call) {
        Context context = getContext();
        String uriStr = prefs(context).getString(KEY_TREE_URI, "");
        if (uriStr == null || uriStr.isEmpty()) {
            call.reject("No backup folder configured");
            return;
        }
        try {
            Uri treeUri = Uri.parse(uriStr);
            ContentResolver cr = context.getContentResolver();
            Uri rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));
            Uri mainUri = findChildDocument(cr, treeUri, rootDocUri, MAIN_FILE);
            byte[] bytes = mainUri != null ? readUriBytes(cr, mainUri) : null;
            String source = MAIN_FILE;
            if (bytes == null || bytes.length < 20) {
                Uri prevUri = findChildDocument(cr, treeUri, rootDocUri, PREV_FILE);
                bytes = prevUri != null ? readUriBytes(cr, prevUri) : null;
                source = PREV_FILE;
            }
            if (bytes == null || bytes.length < 20) {
                call.reject("No valid auto-backup file found in the selected folder");
                return;
            }
            JSObject out = new JSObject();
            out.put("data", new String(bytes, StandardCharsets.UTF_8));
            out.put("source", source);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Failed to read auto-backup: " + e.getMessage());
        }
    }

    private static Uri findChildDocument(ContentResolver cr, Uri treeUri, Uri parentDocUri, String displayName) {
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, DocumentsContract.getDocumentId(parentDocUri));
        String[] proj = new String[] { DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME };
        try (Cursor c = cr.query(childrenUri, proj, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String docId = c.getString(0);
                    String name = c.getString(1);
                    if (displayName.equals(name)) {
                        return DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static Uri findOrCreateDocument(ContentResolver cr, Uri treeUri, Uri parentDocUri, String displayName, String mimeType) throws Exception {
        Uri existing = findChildDocument(cr, treeUri, parentDocUri, displayName);
        if (existing != null) return existing;
        return DocumentsContract.createDocument(cr, parentDocUri, mimeType, displayName);
    }

    private static void writeAndSyncUri(ContentResolver cr, Uri docUri, byte[] bytes) throws Exception {
        try (ParcelFileDescriptor pfd = cr.openFileDescriptor(docUri, "wt")) {
            if (pfd == null) throw new IllegalStateException("openFileDescriptor returned null");
            try (FileOutputStream fos = new FileOutputStream(pfd.getFileDescriptor())) {
                fos.write(bytes);
                fos.flush();
                pfd.getFileDescriptor().sync();
            }
        }
    }

    private static byte[] readUriBytes(ContentResolver cr, Uri docUri) {
        try (InputStream in = cr.openInputStream(docUri)) {
            if (in == null) return null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) != -1) {
                bos.write(buf, 0, r);
            }
            return bos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }
}
