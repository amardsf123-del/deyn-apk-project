# Real-device test: scheduled SMS reminders (must be done on an Android phone with a SIM)

The automated tests prove JavaScript hand-over and the native state machine against simulated Android components.
They do NOT prove that an operator delivers the SMS. This checklist does.

Setup (merchant phone = the one with the SIM; second phone = recipient, any carrier)
1. Install the new debug APK. Open Settings > SMS: enable SMS, grant the SMS permission.
2. In Settings > SMS set "ديون بدون موعد استحقاق / Dettes sans échéance" to 1 if you test with a debt that has no due date.
3. Create a customer whose phone is the recipient's number, add a debt, and set its due date to 2 days ago.
4. Open "تشخيص الإرسال المجدول / Diagnostic des envois programmés". Expected: queue >= 1, SEND_SMS = yes, a work state
   ENQUEUED/RUNNING, sweeper = ENQUEUED. Tap "Copy report" and keep it.

Tests (record result + the diagnostics report after each)
A. App open: within the sending window (09:00-22:00) the reminder is sent within ~1-2 minutes. History shows
   "sent to network", later "delivered" only if the carrier returns a status report.
B. App closed (swipe away from recents, do NOT force-stop): schedule a reminder for ~10 minutes ahead by choosing a
   due date such that step 1 falls at the next reminder hour, or temporarily set the step time to now+10 min in Settings.
   Wait. Expected: SMS arrives on the second phone with the app closed.
C. Reboot: schedule as in B, reboot the phone before the time, do not open the app. Expected: SMS still arrives.
D. Airplane mode / no signal at the due time, then restore: no message while offline; after restore the status goes
   failed -> retry with back-off -> sent. No duplicate on the recipient phone.
E. Permission: revoke SMS permission in system settings before the due time, then grant it again.
   Expected: nothing is sent while revoked; diagnostics show "permission_denied"; after granting + opening the app (or within
   15 min) the reminder is sent once.
F. Partial payment before the reminder: SMS shows the reduced balance. Full payment before it: no SMS at all.
G. Opt-out one customer / global OFF then ON: no SMS for the opted-out customer; the others continue.
H. Second device on the same merchant account: no SMS is sent by it.
I. Long Arabic custom template (> 70 chars): all parts arrive; if the recipient sees separate fragments, note the
   carrier/handset (this is carrier-side concatenation, which no app can detect).
J. Battery: if B fails only on some phones (Xiaomi/Huawei/Oppo...), set the app to "No restrictions"/auto-start and re-test;
   the diagnostics screen shows "battery optimisation exemption".
Report back the copied diagnostics for any failed case.
