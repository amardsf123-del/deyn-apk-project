# PRO_4_HANDOFF.md — وثيقة التسليم والمراجعة التقنية الشاملة للنسخة PRO 4

- **النسخة المرجعية السابقة**: `PRO 3` (`amardsf123-del/deyn-apk-project`, فرع `sms-integration-files`, Commit `0e45321690e20f19ad8a1e54d32a89e69eab068f`)
- **اسم النسخة الجديدة**: `PRO 4` (داخل المجلد الرئيسي `PRO_4`)
- **تاريخ الإعداد**: 14 نوفمبر 2026
- **المفتاح العام المعتمد (`DEYN_PUBLIC_KEY` / Ed25519)**: `uM8GgGamY++GH9e2PTTkluRlzqEVdbnj+MLh4uFYr/Y=`

---

## 1. نتائج التحقق من الملاحظات الثلاث (ما ثبت خطؤه مقابل ما كان سليمًا)

### أولًا: حماية الساعة (`NATIVE_MONO_OFFSET_MS` و`getMonotonicNowMs()`)
- **الحكم**: **ثبت وجود خلل حقيقي في النسخة السابقة**.
- **الدليل البرمجي**:
  - في `sms/completion.js`، كان المتغير `NATIVE_MONO_OFFSET_MS` يُحسب داخل `syncNativeMonotonicClock()` عند استدعاء `DeynBackupPlugin.getMonotonicTime()` (`SystemClock.elapsedRealtime()`) ولكنه **لم يكن يُستخدم إطلاقًا** داخل `window.evaluate()`.
  - كانت الدالة `getMonotonicNowMs()` تعتمد على `performance.now()` فقط، وهو مؤقت يعود إلى `0` عند إغلاق التطبيق وإعادة فتحه.
- **الإصلاح المنفذ في PRO 4**:
  - ربط `getMonotonicNowMs()` مباشرةً بساعة نظام أندرويد الرتيبة `SystemClock.elapsedRealtime()` (`LAST_NATIVE_ELAPSED_MS + (performance.now() - LAST_NATIVE_SYNC_PERF)`).
  - حفظ `lastValidMono` و`lastValidMonoKind` (`'os'` أو `'perf'`) في حالة الساعة بحيث يكشف النظام تقديم الساعة للأمام أو إرجاعها للخلف عبر إغلاق التطبيق وإعادة فتحه ضمن نفس دورة تشغيل الهاتف، ويتحقق بدقة عند ضغط «حسناً».

### ثانيًا: مزامنة تمديد الديون (`captureLocal` و`Core.extendDebt` و`dueAt` و`extensionHistory`)
- **الحكم**: **ثبت وجود خلل حقيقي 100%**.
- **الدليل البرمجي**:
  - في `sync/engine.js`، كانت `buildSnap(S)` و`captureLocal(S, did, now)` تخزنان `snap.tx[t.id] = 1` فقط عند إنشاء المعاملة.
  - عند استدعاء `Core.extendDebt(c, debtId, ...)` لتعديل معاملة دين موجودة (`dueAt`, `originalDueAt`, `extensionHistory`)، كانت `captureLocal` تجد `snap.tx[t.id]` موجودًا (`1`) فتتجاهل التعديل ولا تصدر أي حدث مزامنة!
- **الإصلاح المنفذ في PRO 4**:
  - إضافة دالة `txExtHash(t)` في `sync/engine.js` لحساب بصمة `(dueAt, originalDueAt, extensionHistory)` لكل معاملة دين.
  - تعديل `buildSnap(S)` و`captureLocal(S, did, now)` لإصدار حدث مزامنة جديد من نوع `txf` (`{ k: 'txf', cid, tid, dueAt, originalDueAt, extensionHistory }`) فور تغير بصمة التمديد لأي معاملة موجودة، مع الحفاظ على التوافق التام مع البيانات القديمة (`snap.tx[t.id] === 1`).
  - إضافة التحقق من `txf` في `checkEvent()` وتطبيقه في `applyOne()` باستخدام الساعات المنطقية `HLC` ودمج `extensionHistory` دون تكرار.

### ثالثًا: صلاحيات العامل (`checkEvent` وحدود الفئات والسقف الائتماني)
- **الحكم**: **ثبت وجود ثغرة جزئية في قيود `cf` و`cust+` عند استقبال أحداث مباشرة من العامل**.
- **الدليل البرمجي**:
  - في `sync/engine.js` داخل `checkEvent()`, كان السطر الخاص بـ `cust+` يفحص `validCust(ev.c)` فقط دون فحص أن العامل (`W`) لا يرسل معاملات `tx` مضمّنة داخل `cust+` أو فئة مجهولة أو سقفًا يتجاوز `100000`.
  - وفي `cf` عندما يكون الزبون محظورًا (`cur.seg === 'black'`)، كان العامل يستطيع إرسال أي نص عشوائي كفئة `seg` أو رفع السقف إلى `100000` بغض النظر عن سقف الفئة.
- **الإصلاح المنفذ في PRO 4**:
  - تشديد `checkEvent()` لحدث `cust+` عند `senderRole === 'W'`: منع وجود عناصر في `ev.c.tx`، والتحقق من أن `ev.c.seg` ضمن فئات المتجر المعروفة (`salaried`, `youth`, `daily`, `black`, أو `S.customSegs`)، وأن `0 <= ev.c.ceiling <= 100000`.
  - تشديد `checkEvent()` لحدث `cf` عند `senderRole === 'W'`: حصر فك الحظر في الفئات النشطة المعروفة فقط (ليس نصًا عشوائيًا)، وتقييد السقف الجديد بسقف الفئة المستهدفة (`Math.max(segCeiling, 10000)`).

---

## 2. بنية المشروع وطريقة عمله والعلاقات بين مكوناته

- **`deyn-app/www/index.html`**: واجهة التطبيق الرئيسية (HTML/CSS/JS) ومدمج بها:
  - محرك المزامنة `DeynSyncLib` (المولَّد من `sync/*.js` عبر `tools/embed_sync.py`).
  - آلة حماية الساعة (المطابقة لـ `trusted-time/time-policy.js` و`trusted-time/client.js`).
  - نظام التفعيل والتراخيص `DEYN3` وكود الاسترداد `DEYNR1` وتشفير كلمة المرور `PBKDF2-SHA256`.
  - حزمة SMS والترجمة الفرنسية والتكميل (`sms/engine.js` + `sms/runtime.js` + `sms/i18n.js` + `sms/completion.js`) المدمجة عبر `.github/scripts/integrate_sms.py`.
- **`deyn-app/native/`** (ونسخها الجذرية):
  - `DeynVaultPlugin.java`: خزنة `AES-256-GCM` بمفاتيح Android Keystore وتخزين ثنائي الخانة (`deyn.v2.a` / `deyn.v2.b`).
  - `DeynSyncPlugin.java`: مآخذ TCP المحلية + `NsdManager` (`_deyn._tcp.`) للمزامنة بين أجهزة التاجر عبر Wi-Fi / Hotspot.
  - `DeynSmsPlugin.java`: إرسال SMS متعدد الأجزاء وتتبع حالة كل جزء عبر `PendingIntent` و`SmsStatusReceiver` وجدولة `WorkManager`.
  - `DeynBackupPlugin.java`: النسخ الاحتياطي التلقائي الخارجي عبر SAF (`ACTION_OPEN_DOCUMENT_TREE`) بالكتابة الذرية والسقوط التلقائي إلى `.prev.json` + ساعة `SystemClock.elapsedRealtime()`.
  - `DeynNotifPlugin.java`: إشعارات أندرويد المجدولة (`WorkManager`) وقناة `deyn_overdue_alerts` مع إلغاء المهام فور تسديد الدين.
- **`deyn-keygen/www/index.html`**: مولّد التراخيص المستقل `DEYN3` (`M`/`W`, `1Y`/`2Y`/`LT`) وأكواد استرداد كلمة المرور `DEYNR1`.
- **`.github/workflows/`**: مسارات بناء APK والاختبارات التلقائية في GitHub Actions.
